function gpx = get_gp(gp_x)
gpx = zeros(1,length(gp_x));
for i = 1:length(gp_x)
    gpx(i) = 1/gp_x(i);
end
gp0 = find(gp_x==0);
if gp0
    gpx(gp0) = 0;
end
function disp1 = R_IC(kk,ff,disp0,invkk0)

sdof = length(ff);
d = ff-kk*disp0;
vec = abs(d);
index0 = zeros(sdof,1);
index = zeros(sdof,1);
s = 0;
ep = 0;
for i = 1:sdof
    if vec(i)>ep
        rk = kk(i,:);
        for j = 1:sdof
            if index0(j)==0 && rk(j)~=0
                s = s+1;
                index0(j) = j;
                index(s) = j;
            end
        end
    end
end

s
index = index(1:s);

rb = zeros(sdof,s);
for i = 1:s
    rb(index(i),i) = 1;
end
kkr = rb'*kk*rb;
ffr = rb'*d;
z = kkr\ffr;
disp1 = invkk0*ff;
disp1 = disp1+rb*z;

end
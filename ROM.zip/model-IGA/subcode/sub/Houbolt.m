function [disp,vel,acc]=Houbolt(kk,mm,F,disp,vel,acc,dt,nt)
a0=dt;
a1=dt^2/2;
a2=1/dt^2;
a3=1/6/dt;
invmm=inv(mm);
ke=kk+2*a2*mm;
invke=inv(ke);
for j=1:2
    acc(:,j)=invmm*(F(:,j)-kk*disp(:,j));
    vel(:,j+1)=vel(:,j)+acc(:,j)*dt;
    disp(:,j+1)=disp(:,j)+vel(:,j+1)*dt;
end
acc(:,3)=invmm*(F(:,3)-kk*disp(:,3));
for i=3:nt
    t=(i-1)*dt;
    F1=F(:,i+1)+mm*(5*a2*disp(:,i)-4*a2*disp(:,i-1)+a2*disp(:,i-2));
    disp(:,i+1)=invke*F1;
    acc(:,i+1)=a2*(2*disp(:,i+1)-5*disp(:,i)+4*disp(:,i-1)-disp(:,i-2));
    vel(:,i+1)=a3*(11*disp(:,i+1)-18*disp(:,i)+9*disp(:,i-1)-2*disp(:,i-2));
end
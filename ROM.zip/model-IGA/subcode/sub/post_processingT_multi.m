gcoord = BB(:,1:3);

% ת���������嵥Ԫ
BR2 = [];
inc = 0;
for ipatch = 1:length(BT)
    B = BT(ipatch).B;
    n = size(B,1);
    m = size(B,2);
    l = size(B,3);
    A = 0; e=0; BR=[];
    for k = 1 : l
        for j = 1 : m
            for i = 1 : n
                A = A + 1;
                if i >= (1+1) && j >= (1+1) && k >= (1+1)
                    e = e + 1;
                    for kloc = 0 : 1
                        for jloc = 0 : 1
                            for iloc = 0 : 1
                                B_ = A - kloc*n*m- jloc*n - iloc; % global function number
                                b = kloc*(1+1)*(1+1) + jloc*(1+1)+ iloc + 1; % local function number
                                BR(b,e) = B_; % assign connectivity
                            end
                        end
                    end
                end
            end
        end
    end
    BR1=BR;
    BR1(1,:)=BR(2,:);
    BR1(2,:)=BR(1,:);
    BR1(5,:)=BR(6,:);
    BR1(6,:)=BR(5,:);
    
    BR2 = [BR2 BR1+inc];
    inc = inc + numel(B);
end

% Replace repeat control points
for i = 1:size(rep,1)
    rep_BR = find(BR2==rep(i,1));
    BR2(rep_BR) = rep(i,2);
end

% ����Tecplot
T0 = full (T0);
tecplotTem(BR2,gcoord,T0);

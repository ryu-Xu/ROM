function [ Ke,kinmtx ] = Build_K_Local_2d( dR_dx,Jmod,D,nen )

% Generate B matrix
kinmtx=zeros(3,nen*2);
kinmtx(1,1:2:end) = dR_dx(:,1);
kinmtx(2,2:2:end) = dR_dx(:,2);
kinmtx(3,1:2:end) = dR_dx(:,2);
kinmtx(3,2:2:end) = dR_dx(:,1);

%stiffness matrix
Ke = kinmtx'*D*kinmtx*Jmod;

end

gcoord=zeros(nnp,3);
for i=1:nnp
    gcoord(i,:)=B{i}(1:3);
end


A = 0; e=0; 
for k = 1 : l
    for j = 1 : m
        for i = 1 : n
            A = A + 1;
            if i >= (1+1) && j >= (1+1) && k >= (1+1)
                e = e + 1;
                for kloc = 0 : 1
                    for jloc = 0 : 1
                        for iloc = 0 : 1
                            B_ = A - kloc*n*m- jloc*n - iloc; % global function number
                            b = kloc*(1+1)*(1+1) + jloc*(1+1)+ iloc + 1; % local function number
                            BR(b,e) = B_; % assign connectivity
                        end
                    end
                end
            end
        end
    end
end
BR1=BR;
BR1(1,:)=BR(2,:);
BR1(2,:)=BR(1,:);
BR1(5,:)=BR(6,:);
BR1(6,:)=BR(5,:);

% Replace repeat control points
repcon = n:n:n*m*l;
for i1 = 1:size(BR1,1)*size(BR1,2)
    for i2 = 1:length(repcon)
      if BR1(i1)==repcon(i2)
            BR1(i1) = BR1(i1)-n+1;
        end
   end
end

dsp_t = full(dsp_t);
% ����Tecplot
tecplotdisp(BR1,gcoord,dsp_t);
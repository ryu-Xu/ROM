function disp1 = R_CA_delt(kk,ff,disp0,kk0,invkk0)

sdof = length(ff);
deltk = kk-kk0;
deltd = ff-kk*disp0;
nb = 11;
rb = zeros(sdof,nb);
rb(:,1) = invkk0*deltd;
for i = 2:nb
    vec1 = deltk*rb(:,i-1);
    vec2 = invkk0*vec1;
    rb(:,i) = -vec2;
end
kkr = rb'*kk*rb;
ffr = rb'*deltd;
z = kkr\ffr;
disp1 = disp0+rb*z;
end
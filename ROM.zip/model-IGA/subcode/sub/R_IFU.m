function disp1 = R_IFU(kk,ff,L,kk0,disp0)

sdof = length(ff);

% Record unbalanced DOFs
dr = ff-kk*disp0;
dk = sum(kk-kk0,2);
vec = abs(dr)+abs(dk);
sd = zeros(sdof,1);
nd = 0;
ep = 0;
for i = 1:sdof
    if vec(i)>ep
        nd = nd+1;
        sd(nd) = i;
    end
end
sd = sd(1:nd);
nd

% Calculate the right-hand vecrots or extra constrains
Rb = zeros(sdof,nd);
Ku = zeros(nd,sdof);
du = zeros(nd,1);
for i = 1:nd
    Ku(i,:) = kk(sd(i),:);
    du(i) = dr(sd(i));
    dr(sd(i)) = 0;
    Rb(:,i) = kk(:,sd(i));
end
for i = 1:nd
    Rb(sd(i),:) = 0;
    Rb(sd(i),i) = 1;
end

% Apply extra constrains
V = zeros(sdof,nd);
L = full(L);
for i = nd:-1:1
    l = L(:,sd(i));
    l(sd(i)) = 0;
    V(:,i) = l;
    L(:,sd(i)) = 0;
    L(sd(i),:) = 0;
    L(sd(i),sd(i)) = 1;
end

%==============SMW formula================

B = [V,-Rb,dr];
% parfor i = 1:length(B(1,:))
%     B1(:,i) = L\B(:,i);
%     U = L';
%     B(:,i) = U\B1(:,i);
% end
B1 = L\B;
L = L';
B = L\B1;
T = B(:,1:nd);
X0 = B(:,nd+1:2*nd+1);
% x0 = B(:,2*nd+1);
clear B
    
K = eye(nd);
K = K+V'*T;
V1 = V'*X0;
V2 = K\V1;
clear V1
dX = T*V2;
clear V2
X = X0-dX;
B = X(:,1:nd);
x0 = X(:,nd+1);
clear X0 dX L V K

du = du-Ku*x0;
Kr = Ku*B;
z = Kr\du;
dx = B*z+x0;

%B = [V,Rb];
%L = L';
%B = L\B1;
%T = B(:,1:nd);
%X0 = B(:,nd+1:2*nd);
%clear B
%K = eye(nd);
%K = K+V'*T;
%V1 = V'*X0;
%V2 = K\V1;
%clear V1
%dX = T*V2;
%clear V2
%B = X0-dX;
%Kr=Rb1*B;
%z = Kr\Fr;
%dx = B*z;
%disp1 = disp0+dx;
%=====================================


% dx = B*z;
disp1 = disp0+dx;

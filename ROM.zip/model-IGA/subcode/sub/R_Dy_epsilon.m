function [disp,vel,acc] = R_Dy_epsilon(K,M,C,F,disp,vel,acc,dt,nt,kk0,invkk0)
gama = 0.5;
beta = 0.25;
a0 = 1/beta/dt^2;
a1 = gama/beta/dt;
a2 = 1/beta/dt;
a3 = 1/2/beta-1;
a4 = gama/beta-1;
a5 = dt/2*(gama/beta-2);
a6 = dt*(1-gama);
a7 = gama*dt;
K1 = K+a0*M+a1*C; % �γ���Ч�ĸնȾ���
acc(:,1) = M\(F(:,1)-K*disp(:,1)-C*vel(:,1)); % t=0ʱ�̵ļ��ٶ�
for i = 2:nt+1
    t = (i-1)*dt;
    F1 = F(:,i)+M*(a0*disp(:,i-1)+a2*vel(:,i-1)+a3*acc(:,i-1))...
        +C*(a1*disp(:,i-1)+a4*vel(:,i-1)+a5*acc(:,i-1)); % ��Ч�غ�
    
    % epsilon algorithm
    %s = [rb(:,1),rb(:,1)+rb(:,2),rb(:,1)+rb(:,2)+rb(:,3)];
    s = zeros(sdof,nb);
    for i = 1:nb
        s(:,i) = z(i)*rb(:,i);
    end
    for i = 1:sdof
        %s1 = 1/(s(i,2)-s(i,1));
        %s2 = 1/(s(i,3)-s(i,2));
        %disp1(i) = s(i,2)+1/(s2-s1);
        s1 = 1/s(i,2);
        s2 = 1/s(i,3);
        disp1(i) = s(i,1)+s(i,2)+1/(s2-s1);
    end
    
    disp(:,i) = R_CA(K1,F1,kk0,invkk0);
    acc(:,i) = a0*(disp(:,i)-disp(:,i-1))-a2*vel(:,i-1)-a3*acc(:,i-1);
    vel(:,i) = vel(:,i-1)+a6*acc(:,i-1)+a7*acc(:,i);
end

end
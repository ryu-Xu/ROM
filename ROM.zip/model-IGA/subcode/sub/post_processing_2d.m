stress_n = zeros(nnp,4);
ai = zeros(2*nen,nel);
num_node = zeros(nnp,1);
for q = 1 : nel
    ai(:,q)=d(LM(:,q)) ;
    ni = INN(IEN(1,q),1);
    nj = INN(IEN(1,q),2);
    
    % Check if element has zero measure
    if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj))
        continue
    end
    gp = 1;
    np = 1;
    stress_g = [];
    for i = 1 : NQUADx % Loop trough Gauss points
        for j = 1 : NQUADy
            % Gauss point
            GP.xi_tilde = gp_x(i);
            GP.eta_tilde = gp_y(j);
            
            % Get Basis, derivatives, and det(J) for current gauss pt
            [ R,dR_dx,Jdet ] = Shape_function_2d( GP,q,deg,B,KV,INN,IEN);
            
            % Combine quadrature weights with det(J)
            Jmod = abs(Jdet)*w_x(i)*w_y(j);
            
            % Build Ke
            [ Ke_,kinmtx ] = Build_K_Local_2d( dR_dx,Jmod,D,nen );
            
            % Stress
            strain(:,gp,q)=kinmtx*ai(:,q);
            siga=D*strain(:,gp,q);
            gstress=zeros(1,4);
            gstress(1:3)=siga(1:3)';
            
            stress_g = [stress_g;gstress];
            num_node(IEN(gp,q))= num_node(IEN(gp,q))+1;
            gp=gp+1;
        end
    end
    
    % Stress recovery
    gpx = get_gp(gp_x);
    gpy = get_gp(gp_y);
    H = []; % Stress recovery matrix
    for gpi = 1:NQUADx
        for gpj = 1:NQUADy
            GP1.xi_tilde = gpx(gpi);
            GP1.eta_tilde = gpy(gpj);
            H1 = Shape_function_2d( GP1,q,deg,B,KV,INN,IEN)';
            H = [H;H1];
        end
    end
    stress = H*stress_g;
    % von Mises stress
    gp = 1;
    for i = 1 : NQUADx
        for j = 1 : NQUADy
            stress(gp,4)=(((stress(gp,1)-stress(gp,2))^2+stress(gp,2)^2+...
                stress(gp,1)^2)/2)^0.5;
            gp = gp+1;
        end
    end
    gp = 1;
    for i = 1 : NQUADx
        for j = 1 : NQUADy
            stress_n(IEN(gp,q),:)=stress_n(IEN(gp,q),:)+stress(gp,:);
            gp = gp+1;
        end
    end
end
for i=1:nnp
    num=num_node(i);
    stress_n(i,:)=stress_n(i,:)./num;
end
P = zeros(nnp,2);
for i=1:nnp
    P(i,:)=B{i}(1:2);
end

% ����Ӧ����ͼ ֻʹ����data1
% figure;
% [X,Y,Z] = griddata(P(:,1),P(:,2),stress_n(:,4),linspace(0,La,100)',linspace(0,Lb,100),'v4');
% pcolor(X,Y,Z)
% shading interp
% colormap jet
% axis equal

gcoord=zeros(nnp,2);
for i=1:nnp
    gcoord(i,:)=B{i}(1:2)+d(2*i-1:2*i);
end

% ת�����ı��ε�Ԫ
A = 0; e=0; 
for j = 1 : m
    for i = 1 : n
        A = A + 1;
        if i >= (1+1) && j >= (1+1)
            e = e + 1;
            for jloc = 0 : 1
                for iloc = 0 : 1
                    B_ = A - jloc*n - iloc; % global function number
                    b = jloc*(1+1)+ iloc + 1; % local function number
                    BR(b,e) = B_; % assign connectivity
                end
            end
        end
    end
end
BR1=BR;
BR1(1,:)=BR(2,:);
BR1(2,:)=BR(1,:);

% Replace repeat control points
for i = 2:numel(B)
    for j = 1:i-1
        if B{i}(1)==B{j}(1) && B{i}(2)==B{j}(2) && B{i}(3)==B{j}(3)
            rep_BR = find(BR1==i);
            BR1(rep_BR) = j;
        end
    end
end

% ����Tecplot
d = full(d);
tecplot_static_2d(BR1,gcoord,stress_n,d);

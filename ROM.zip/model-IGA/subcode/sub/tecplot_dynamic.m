function  tecplot_dynamic(IEN,gcoord,stress_nn,d)

nel = size(IEN,2);
node= size(stress_nn,1);
nodedata=fopen('dynamic_result.plt','w');      
fprintf(nodedata,'TITLE="data"\n');    
fprintf(nodedata,'VARIABLES=,"X", "Y","Z" ,"Mises stress","Disp X","Disp Y","Disp Z"\n');

for ii=1:size(stress_nn,2)
    fprintf(nodedata,'ZONE T="%d  "  ,  N=%d, E=%d, ET=BRICK, F=FEPOINT\n',ii,node,nel); 
    sigm1=stress_nn(:,ii);sigm2=d(1:3:end,ii);sigm3=d(2:3:end,ii);sigm4=d(3:3:end,ii);
    for i=1:node
        fprintf(nodedata,'%10.10f,%10.10f,%10.10f,%10.10f,%10.10f,%10.10f,%10.10f\n',...
            gcoord(3*i-2,ii),gcoord(3*i-1,ii),gcoord(3*i,ii),sigm1(i),sigm2(i),sigm3(i),sigm4(i));
    end
    for j=1:nel
        for i=1:size(IEN,1)
            fprintf(nodedata,'%d       ',IEN(i,j));
        end
        fprintf(nodedata,'\n');
    end
end
stress_n = zeros(nnp,4);
ai = zeros(3*nen,nel);num_node = zeros(nnp,1);
for qi = 1 : nel
    ai(:,qi)=d(LM(:,qi)) ;
    ni = INN(IEN(1,qi),1);
    nj = INN(IEN(1,qi),2);
    nk = INN(IEN(1,qi),3);
    
    % Check if element has zero measure
    if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj)) || (KV.Zeta(nk+1) == KV.Zeta(nk))
        continue
    end
    gp = 1;np = 1;
    stress_g = [];
    for i = 1 : NQUADx % Loop trough Gauss points
        for j = 1 : NQUADy
            for k = 1 : NQUADz
                % Gauss point
                GP.xi_tilde = gp_x(i);
                GP.eta_tilde = gp_y(j);
                GP.zeta_tilde = gp_z(k);
                
                % Get Basis, derivatives, and det(J) for current gauss pt
                [ R,dR_dx,Jdet ] = Shape_function( GP,qi,deg,B,KV,INN,IEN);
                
                % Combine quadrature weights with det(J)
                Jmod = abs(Jdet)*w_x(i)*w_y(j)*w_z(k);
                
                % Build Ke
                [ Ke_,kinmtx ] = Build_K_Local( dR_dx,Jmod,D,nen );
                
                % Stress
                strain(:,gp,qi)=kinmtx*ai(:,qi);
                siga=D*strain(:,gp,qi);
                gstress=zeros(1,4);
                gstress(1:3)=siga(1:3)';
                
                stress_g = [stress_g;gstress];
                num_node(IEN(gp,qi))= num_node(IEN(gp,qi))+1;
                gp=gp+1;
            end
        end
    end
    
    % Stress recovery
    gpx = get_gp(gp_x);
    gpy = get_gp(gp_y);
    gpz = get_gp(gp_z);
    H = []; % Stress recovery matrix
    for gpi = 1:NQUADx
        for gpj = 1:NQUADy
            for gpk = 1:NQUADz
                GP1.xi_tilde = gpx(gpi);
                GP1.eta_tilde = gpy(gpj);
                GP1.zeta_tilde = gpz(gpk);
                H1 = Shape_function( GP1,qi,deg,B,KV,INN,IEN)';
                H = [H;H1];
            end
        end
    end
    stress = H*stress_g;
    % von Mises stress
    gp = 1;
    for i = 1 : NQUADx
        for j = 1 : NQUADy
            for k = 1 : NQUADz
                stress(gp,4)=(((stress(gp,1)-stress(gp,2))^2+(stress(gp,2)-...
                    stress(gp,3))^2+(stress(gp,3)-stress(gp,1))^2)/2)^0.5;
                gp = gp+1;
            end
        end
    end
    gp = 1;
    for i = 1 : NQUADx
        for j = 1 : NQUADy
            for k = 1 : NQUADz
                stress_n(IEN(gp,qi),:)=stress_n(IEN(gp,qi),:)+stress(gp,:);
                gp = gp+1;
            end
        end
    end
end

gcoord=zeros(nnp,3);
for i=1:nnp
    gcoord(i,:)=B{i}(1:3);
end

for i=1:nnp
    num=num_node(i);
    stress_n(i,:)=stress_n(i,:)./num;
end

% ת���������嵥Ԫ
A = 0; e=0; 
for k = 1 : l
    for j = 1 : m
        for i = 1 : n
            A = A + 1;
            if i >= (1+1) && j >= (1+1) && k >= (1+1)
                e = e + 1;
                for kloc = 0 : 1
                    for jloc = 0 : 1
                        for iloc = 0 : 1
                            B_ = A - kloc*n*m- jloc*n - iloc; % global function number
                            b = kloc*(1+1)*(1+1) + jloc*(1+1)+ iloc + 1; % local function number
                            BR(b,e) = B_; % assign connectivity
                        end
                    end
                end
            end
        end
    end
end
BR1=BR;
BR1(1,:)=BR(2,:);
BR1(2,:)=BR(1,:);
BR1(5,:)=BR(6,:);
BR1(6,:)=BR(5,:);

% Replace repeat control points
for i = 2:numel(B)
    for j = 1:i-1
        if B{i}(1)==B{j}(1) && B{i}(2)==B{j}(2) && B{i}(3)==B{j}(3) && B{i}(4)==B{j}(4)
            rep_BR = find(BR1==i);
            BR1(rep_BR) = j;
        end
    end
end

% ����Tecplot
d = full(d);
tecplot_static(BR1,gcoord,stress_n,d);

function [disp,vel,acc]=Newmark(K,M,C,F,disp,vel,acc,dt,nt)
gama = 0.5;
beta = 0.25;
a0 = 1/beta/dt^2;
a1 = gama/beta/dt;
a2 = 1/beta/dt;
a3 = 1/2/beta-1;
a4 = gama/beta-1;
a5 = dt/2*(gama/beta-2);
a6 = dt*(1-gama);
a7 = gama*dt;
K1 = K+a0*M+a1*C; % �γ���Ч�ĸնȾ���

acc(:,1) = M\(F(:,1)-K*disp(:,1)-C*vel(:,1)); % t=0ʱ�̵ļ��ٶ�
for i = 2:nt+1
    t = (i-1)*dt;
    f1 = F(:,i)+M*(a0*disp(:,i-1)+a2*vel(:,i-1)+a3*acc(:,i-1))...
        +C*(a1*disp(:,i-1)+a4*vel(:,i-1)+a5*acc(:,i-1)); % ��Ч�غ�
    disp(:,i) = K1\f1;
    acc(:,i) = a0*(disp(:,i)-disp(:,i-1))-a2*vel(:,i-1)-a3*acc(:,i-1);
    vel(:,i) = vel(:,i-1)+a6*acc(:,i-1)+a7*acc(:,i);
end
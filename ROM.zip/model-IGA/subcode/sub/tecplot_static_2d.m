function  tecplot_static_2d(IEN,gcoord,stress_n,d)

nel = size(IEN,2);
node= size(gcoord,1);
nodedata=fopen('static_result.plt','w');  
fprintf(nodedata,'TITLE="data"\n');
fprintf(nodedata,'VARIABLES=,"X", "Y","Mises stress","Disp X","Disp Y"\n');
fprintf(nodedata,'ZONE T="%d  "  ,  N=%d, E=%d, ET=QUADRILATERAL, F=FEPOINT\n',1,node,nel);
sigm1 = d(1:2:end);
sigm2 = d(2:2:end);

for i=1:node
    fprintf(nodedata,'%10.10f,%10.10f,%10.10f,%10.10f,%10.10f\n',...
      gcoord(i,1),gcoord(i,2),stress_n(i),sigm1(i),sigm2(i));
end  

for i=1:nel
    for j=1:size(IEN,1)
        fprintf(nodedata,'%d       ',IEN(j,i));  
    end
    fprintf(nodedata,'\n');
end

end
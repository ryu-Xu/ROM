function [disp,vel,acc]=cendiff(kk,mm,F,disp,vel,acc,dt,nt)
c0=1/(dt^2);
c1=1/(2*dt);
c2=2*c0;
c3=1/c2;
mm1=c0*mm;
invmm1=inv(mm1);
acc(:,1)=mm\(F(:,1)-kk*disp(:,1));%t=0ʱ�̵ļ��ٶ�
disp_t=disp(:,1)-dt*vel(:,1)+c3*acc(:,1);
disp(:,2)=invmm1*(F(:,1)-(kk-c2*mm)*disp(:,1)-c0*mm*disp_t);
for i=2:nt
    t=(i-1)*dt;
    f1=F(:,i)-(kk-c2*mm)*disp(:,i)-c0*mm*disp(:,i-1);
    disp(:,i+1)=invmm1*f1;
    acc(:,i)=c0*(disp(:,i-1)-2*disp(:,i)+disp(:,i+1));
    vel(:,i)=c1*(disp(:,i+1)-disp(:,i-1));
end
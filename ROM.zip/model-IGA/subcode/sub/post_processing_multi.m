stress_n = zeros(nnpT,4);
num_node = zeros(nnpT,1);
e0 = 0;
for ipatch = 1:length(BT)
    KV = KVT(ipatch);
    B = BT(ipatch).B;
    deg = degT(ipatch);
    nel = Con(ipatch).nel;
    nen = Con(ipatch).nen;
    INN = Con(ipatch).INN;
    IEN = Con(ipatch).IEN;
    
    % Gauss-Legendre quadrature points:
    [ gp_x,w_x ] = getGP( deg.p );
    [ gp_y,w_y ] = getGP( deg.q );
    [ gp_z,w_z ] = getGP( deg.r );
    NQUADx = size(gp_x,2);
    NQUADy = size(gp_y,2);
    NQUADz = size(gp_z,2);
    
    ai = zeros(3*nen,nel);
    for e = 1 : nel
        ai(:,e) = d(LM(:,e0+e));
        ni = INN(IEN(1,e),1);
        nj = INN(IEN(1,e),2);
        nk = INN(IEN(1,e),3);
        
        % Check if element has zero measure
        if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj)) || (KV.Zeta(nk+1) == KV.Zeta(nk))
            continue
        end
        
        gp = 1;np = 1;
        stress_g = [];
        for i = 1 : NQUADx % Loop trough Gauss points
            for j = 1 : NQUADy
                for k = 1 : NQUADz
                    % Gauss point
                    GP.xi_tilde = gp_x(i);
                    GP.eta_tilde = gp_y(j);
                    GP.zeta_tilde = gp_z(k);
                    
                    % Get Basis, derivatives, and det(J) for current gauss pt
                    [ R,dR_dx,Jdet ] = Shape_function( GP,e,deg,B,KV,INN,IEN);
                    
                    % Combine quadrature weights with det(J)
                    Jmod = abs(Jdet)*w_x(i)*w_y(j)*w_z(k);
                    
                    % Build Ke
                    [ Ke_,kinmtx ] = Build_K_Local( dR_dx,Jmod,D,nen );
                    
                    % Stress
                    strain(:,gp,e)=kinmtx*ai(:,e);
                    siga=D*strain(:,gp,e);
                    gstress=zeros(1,4);
                    gstress(1:3)=siga(1:3)';
                    
                    stress_g = [stress_g;gstress];
                    num_node(IENT(gp,e0+e))= num_node(IENT(gp,e0+e))+1;
                    gp = gp+1;
                end
            end
        end
        
        % Stress recovery
        gpx = get_gp(gp_x);
        gpy = get_gp(gp_y);
        gpz = get_gp(gp_z);
        H = []; % Stress recovery matrix
        for gpi = 1:NQUADx
            for gpj = 1:NQUADy
                for gpk = 1:NQUADz
                    GP1.xi_tilde = gpx(gpi);
                    GP1.eta_tilde = gpy(gpj);
                    GP1.zeta_tilde = gpz(gpk);
                    H1 = Shape_function( GP1,e,deg,B,KV,INN,IEN)';
                    H = [H;H1];
                end
            end
        end
        stress = H*stress_g;
        % von Mises stress
        gp = 1;
        for i = 1 : NQUADx
            for j = 1 : NQUADy
                for k = 1 : NQUADz
                    stress(gp,4)=(((stress(gp,1)-stress(gp,2))^2+(stress(gp,2)-...
                        stress(gp,3))^2+(stress(gp,3)-stress(gp,1))^2)/2)^0.5;
                    gp = gp+1;
                end
            end
        end
        gp = 1;
        for i = 1 : NQUADx
            for j = 1 : NQUADy
                for k = 1 : NQUADz
                    stress_n(IENT(gp,e0+e),:)=stress_n(IENT(gp,e0+e),:)+stress(gp,:);
                    gp = gp+1;
                end
            end
        end
    end
    e0 = e0 + nel;
end

gcoord = BB(:,1:3);

for i = 1:nnpT
    num = num_node(i);
    stress_n(i,:)=stress_n(i,:)./num;
end

% ת���������嵥Ԫ
BR2 = [];
inc = 0;
for ipatch = 1:length(BT)
    B = BT(ipatch).B;
    n = size(B,1);
    m = size(B,2);
    l = size(B,3);
    A = 0; e=0; BR=[];
    for k = 1 : l
        for j = 1 : m
            for i = 1 : n
                A = A + 1;
                if i >= (1+1) && j >= (1+1) && k >= (1+1)
                    e = e + 1;
                    for kloc = 0 : 1
                        for jloc = 0 : 1
                            for iloc = 0 : 1
                                B_ = A - kloc*n*m- jloc*n - iloc; % global function number
                                b = kloc*(1+1)*(1+1) + jloc*(1+1)+ iloc + 1; % local function number
                                BR(b,e) = B_; % assign connectivity
                            end
                        end
                    end
                end
            end
        end
    end
    BR1=BR;
    BR1(1,:)=BR(2,:);
    BR1(2,:)=BR(1,:);
    BR1(5,:)=BR(6,:);
    BR1(6,:)=BR(5,:);
    
    BR2 = [BR2 BR1+inc];
    inc = inc + numel(B);
end

% Replace repeat control points
for i = 1:size(rep,1)
    rep_BR = find(BR2==rep(i,1));
    BR2(rep_BR) = rep(i,2);
end

% ����Tecplot
d = full(d);
tecplot_static(BR2,gcoord,stress_n,d);

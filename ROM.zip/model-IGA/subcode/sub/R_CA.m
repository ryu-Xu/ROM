function disp1 = R_CA(kk,ff,kk0,invkk0)

sdof = length(ff);
deltk = kk-kk0;
nb = 4;
rb = zeros(sdof,nb);
rb(:,1) = invkk0*ff;
for i = 2:nb
    vec1 = deltk*rb(:,i-1);
    vec2 = invkk0*vec1;
    rb(:,i) = -vec2;
end
kkr = rb'*kk*rb;
ffr = rb'*ff;
z = kkr\ffr;
disp1 = rb*z;

% ʩ����������
% vb = zeros(sdof,nb);
% v_ = zeros(sdof,nb);
% rkr0 = kk*rb(:,1);
% rkr1 = rb(:,1)'*rkr0;
% vb(:,1) = rb(:,1)/sqrt(rkr1);
% for i = 2:nb
%     rkvv = zeros(sdof,1);
%     for j = 1:i-1
%         rkv0 = kk*vb(:,j);
%         rkv1 = rb(:,i)'*rkv0;
%         rkv2 = rkv1*vb(:,j);
%         rkvv = rkvv+rkv2;
%     end
%     v_(:,i) = rb(:,i)-rkvv;
%     vkv0 = kk*v_(:,i);
%     vkv1 = v_(:,i)'*vkv0;
%     vb(:,i) = v_(:,i)/sqrt(vkv1);
% end
% vv1 = zeros(sdof,sdof);
% for i = 1:nb
%     vv0 = vb(:,i)*vb(:,i)';
%     vv1 = vv1+vv0;
% end
% disp1 = vv1*ff;

end
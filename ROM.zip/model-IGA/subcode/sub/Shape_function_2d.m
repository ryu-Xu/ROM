function [ R,dR_dx,J ] = Shape_function_2d( GP,e,deg,B,KV,INC,IEN)

p = deg.p;
q = deg.q;

% number of local basis functions:
nen = (p+1)*(q+1); 

% NURBS coordinates; convention consistent with Algorithm 7
ni = INC(IEN(1,e),1);
nj = INC(IEN(1,e),2);
  
xi = ((KV.Xi(ni+1)-KV.Xi(ni))*GP.xi_tilde ...
+ (KV.Xi(ni+1)+KV.Xi(ni))) / 2;
eta = ((KV.Eta(nj+1)-KV.Eta(nj))*GP.eta_tilde ...
+ (KV.Eta(nj+1)+KV.Eta(nj))) / 2;

% Calculate univariate B-spline functions using (2.1) and (2.2)
% and their derivatives using (2.12)
N1 = Der1BasisFun(ni-1,xi,p,KV.Xi)'; % xi-dir.
N2 = Der1BasisFun(nj-1,eta,q,KV.Eta)'; % eta-dir.
N = N1(:,1);
dN_dxi = N1(:,2);
M = N2(:,1);
dM_deta = N2(:,2);

% Build numerators and denominators (in local numbering)
x = zeros(1,nen);
y = zeros(1,nen);
R = zeros(nen,1);   % Array of trivariate NURBS basis functions
dR_dxi = zeros(nen,2); % Trivariate NURBS function derivatives
                       % w.r.t. parametric coordinates
loc_num = 0; % Local basis function counter

for j = 0 : q
    for i = 0 : p
        loc_num = loc_num + 1;
        
        R(loc_num) = N(p+1-i)*M(q+1-j)* B{ni-i,nj-j}(4);
        % Get coordinates in local numbering
        x(loc_num) = B{ni-i,nj-j}(1) ;
        y(loc_num) = B{ni-i,nj-j}(2);
        
        dR_dxi(loc_num,1) = dN_dxi(p+1-i)*M(q+1-j)* B{ni-i,nj-j}(4);
        dR_dxi(loc_num,2) = N(p+1-i)*dM_deta(q+1-j)* B{ni-i,nj-j}(4);
    end
end
W = sum(R); % Function denominator (Sum(N*M*L*w))
dW_dxi = sum(dR_dxi(:,1)); % Derivative denominator (Sum(dN*M*L*w))
dW_deta = sum(dR_dxi(:,2)); % Derivative denominator (Sum(N*dM*L*w))
            
% Divide by denominators to complete definitions of functions
% and derivatives w.r.t. parametric coordinates
dR_dxi(:,1) = (dR_dxi(:,1)*W - R*dW_dxi) / W^2;         
dR_dxi(:,2) = (dR_dxi(:,2)*W - R*dW_deta) / W^2;
R = R/W;

% Gradient of mapping from parameter space to physical space
dx_dxi = [x;y] * dR_dxi;

% Compute derivatives of basis functions
% with respect to physical coordinates
% if dx_dxi(1,1) == 0
%     dx_dxi(1,1) = 1;
% end
% if dx_dxi(2,2) == 0
%     dx_dxi(2,2) = 1;
% end
dR_dx = dR_dxi/dx_dxi; %dR_dxi * inv(dx_dxi)

% Gradient of mapping from parent element to parameter space
dxi_dtildexi=zeros(2); % Derivative of parametric coordinates
                       % w.r.t. parent element coordinates
dxi_dtildexi(1,1) = (KV.Xi(ni+1)-KV.Xi(ni))/2;
dxi_dtildexi(2,2) = (KV.Eta(nj+1)-KV.Eta(nj))/2;

% Compute the Jacobian
J_mat = dx_dxi*dxi_dtildexi;

% Compute Jacobian determinant
J = det(J_mat);

end
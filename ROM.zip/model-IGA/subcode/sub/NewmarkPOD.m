function [acc,vel,dsp,es_list]=NewmarkPOD(kk,cc,mm,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a)
%--------------------------------------------------------------------------
%  Purpose:
%     The function subroutine TransResp5.m calculates transient response of
%     a structural system using Newmark integration scheme.
%  Synopsis:
%     [acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0)
%  Variable Description:
%     Input parameters
%       kk, cc, mm - stiffness, damping and mass matrices
%       fd - Input or forcing influence matrix
%       bcdof - Boundary condition dofs vector
%       nt - Number of time steps
%       dt - Time step size
%       q0, dq0 - Initial condition vectors
%     Output parameters
%       acc - Acceleration response
%       vel - Velocity response
%       dsp - Displacement response
%--------------------------------------------------------------------------
%  (1) initial condition
%--------------------------------------------------------------------------
% [sdof,n2]=size(kk);
es_list = [];
[sdof] = size(phy,1);
L = size(snapshots_d,2);
 
dsp=zeros(sdof,nt);                                         % displacement matrix
vel=zeros(sdof,nt);                                             % velocity matrix
acc=zeros(sdof,nt);                                          % acceleration matrix

dsp(:,1:L) = snapshots_d;
vel(:,1:L) = snapshots_v;
acc(:,1:L) = snapshots_a;

dsp_r = cell(1+nt,1);
for i = 1:L
dsp_r{i} = phy'*dsp(:,i);
end
alpha=0.8; beta=0.7;                                        % select the parameters
%--------------------------------------------------------------------------
%  (2) Newmark integration scheme for time integration
%--------------------------------------------------------------------------

ekk=kk+mm/(alpha*dt^2)+cc*beta/(alpha*dt);

%�ӱ߽�����
ekk = bck2(bcdof,ekk);

ekk_r = phy'*ekk*phy;

jishu = 0;

for it=L:nt                                              % loop for each time step
jishu = jishu + 1;

% ����1   ÿ���ٲ���ͨ��ԭ���Ľ��������ɻ������Եͽ׽���������
% ȡ4��˲��
% ��3���ͽ׽�
%     if mod(it,401) == 0
%         snapshots = dsp(:,it-9:it);
%         U = s_svd(snapshots);
% %         r = POD_jieduan(S,0.9999);
%         r = 6;
%         phy = U(:,1:r);
%  
%         ekk_r = phy'*ekk*phy;
%         for i = 1:3
%             dsp_r{it-3+i} = phy'*dsp(:,it-3+i);
%         end
%     end
%     
% ����3   ÿ��pod���������ڶ��٣�ȡ�ͽ׽Ⲣ����POD��
% if size(phy,2) >= 120
% [phy,ekk_r,dsp_r(it-2:it)]=update_phy(phy,ekk,dsp_r(it-2:it),dsp(:,it-2:it));
% end
%%%  ����2  ÿ���ٲ���ͨ��SVD�ѻ�����
%         if mod(it,1701) == 0
%             [phy_n,S,~] = svd(phy);
%             phy = phy_n(:,1:20);
%             
%             ekk_r = phy'*ekk*phy;
%             
%             for i = 1:5
%                 dsp_r{it-5+i} = phy'*dsp(:,it-5+i);
%             end
%         end

  cfm=dsp(:,it)/(alpha*dt^2)+vel(:,it)/(alpha*dt)+acc(:,it)*(0.5/alpha-1);
  cfc=dsp(:,it)*beta/(alpha*dt)+vel(:,it)*(beta/alpha-1)...
     +acc(:,it)*(0.5*beta/alpha-1)*dt;
  efd=fd(:,it)+mm*cfm+cc*cfc;                  %  compute the effective force vector
  %�ӱ߽�����
  efd = bcf2(bcdof,efd);
  efd_r = phy'*efd;
%   dsp(:,it+1)=inv(ekk)*efd;                        % find the displacement at time t+dt
  dsp_r{it+1} = ekk_r\efd_r;
  dsp(:,it+1) = phy*dsp_r{it+1};
  acc(:,it+1)=(dsp(:,it+1)-dsp(:,it))/(alpha*dt^2)-vel(:,it)/(alpha*dt)...
              -acc(:,it)*(0.5/alpha-1);              % find the acceleration at time t+dt
  vel(:,it+1)=vel(:,it)+acc(:,it)*(1-beta)*dt+acc(:,it+1)*beta*dt;
                                                  % find the velocity at time t+dt
     % assign zero to acc, vel, dsp of the dofs associated with bc
    
    %�ж���� 
    threshold = 1e-6;%��ֵ

    if jishu == 3
        jishu = 0;
    e = ekk*dsp(:,it+1)-efd;
    el2 = sqrt(norm(e,2)/norm(efd,2));
    es_list = [es_list,el2];
%         es = norm(e,1);%���1-����
%         es = mean(abs(e)./efd);%���ְٷֱȷ��������ų�efd��0����ܣ�������NAN

    if el2>threshold %& mod(it,201) ~= 0
        %���� ʹ�������󷨣����ϵ�λ��
         [phy,ekk_r] = replacepod_K(phy,ekk,dsp_r(it-1:it+1),e,2);%��ϸ߽�SVD
%         [phy,ekk_r,dsp_r(it-1:it+1)] = replacepod_K3(phy,ekk,dsp_r(it-1:it+1),e,2,dsp(:,it-1:it+1));%��ϵͽ�SVD
%           elseif es>threshold & mod(it,201) == 0
%         [phy,ekk_r] = replacepod_K2(ekk,dsp(:,it-9:it+1),e,1);
            %0914,����֤����һ��û��
%         for i = 1:5
%             dsp(:,it-4+i) = phy*dsp_r{it-4+i};
%             acc(:,it-4+i)=(dsp(:,it-4+i)-dsp(:,it-5+i))/(alpha*dt^2)-vel(:,it-5+i)/(alpha*dt)...
%               -acc(:,it-4+i)*(0.5/alpha-1);              % find the acceleration at time t+dt
%             vel(:,it-4+i)=vel(:,it-5+i)+acc(:,it-5+i)*(1-beta)*dt+acc(:,it-4+i)*beta*dt;
% 
%             %����ȥ�Ľ���ϱ߽�����
% %              for is=1:sdof
% %                 if bcdof(is)==1
% %                   dsp(is,it-4+i)=0;
% %                   vel(is,it-4+i)=0;
% %                   acc(is,it-4+i)=0;
% %                 end
% %               end
%         end
    end
    end               
%                            
%  %%�ӱ߽����� 
%  
%  for i=1:sdof
%     if bcdof(i)==1
%       dsp(i,it+1)=0;
%       vel(i,it+1)=0;
%       acc(i,it+1)=0;
%     end
%   end

end

if cc(1,1)==0
  disp('The transient response results of undamping system')
else
  disp('The transient response results of damping system')
end
 
disp('The method is Newmark POD integration')

%--------------------------------------------------------------------------
%     The end
%--------------------------------------------------------------------------


% |       ———————
%        |      2      |
%        |  1   ○  3  |
%        |      4      |
%    (0,0)———————

d  = 4; %方板边长
r1 = 1;  %小圆孔半径
a = (d*0.5*sqrt(2)-r1)/sqrt(2); %斜线横坐标
%% Patch 1-4 左下角带孔方块
% Patch 1 上 3*3*2
Xi = [0,0,0,1,1,1];
Eta = [0,0,0,1,1,1];
k_ = length(Xi);
l_ = length(Eta);
B = cell(3,3);
B{1,1} = [0 0 0 1];
B{2,1} = [0 d/2 0 1];
B{3,1} = [0 d 0 1];
B{1,2} = [d/4 d/4 0 1];
B{2,2} = [d/4 d/2 0 1];
B{3,2} = [d/4 d*3/4 0 1];
B{1,3} = [a a 0 1];
B{2,3} = [a-r1/sqrt(2) d/2 0 1/sqrt(2)];
B{3,3} = [a d-a 0 1];
n = size(B,1);
m = size(B,2);
p = k_-n-1;
q = l_-m-1;
[ X_ ] = getSubDivKVValues( Xi, 1);
[B,Xi]=RefineKnotSolidXi( B,p,Xi,X_ );
[ E_ ] = getSubDivKVValues( Eta, 1);
[B,Eta]=RefineKnotSolidEta( B,q,Eta,E_ );
BT(1).B = B;
KVT(1).Xi = Xi;
KVT(1).Eta = Eta;
degT(1).p = p;
degT(1).q = q;

% Patch 2 右 3*3*2
Xi = [0,0,0,1,1,1];
Eta = [0,0,0,1,1,1];
k_ = length(Xi);
l_ = length(Eta);
B = cell(3,3);
B{1,1} = [0 d 0 1];
B{2,1} = [d/2 d 0 1];
B{3,1} = [d d 0 1];
B{1,2} = [d/4 d*3/4 0 1];
B{2,2} = [d/2 d*3/4 0 1];
B{3,2} = [d*3/4 d*3/4 0 1];
B{1,3} = [a d-a 0 1];
B{2,3} = [d/2 d-a+r1/sqrt(2) 0 1/sqrt(2)];
B{3,3} = [d-a d-a 0 1];
n = size(B,1);
m = size(B,2);
p = k_-n-1;
q = l_-m-1;
[ X_ ] = getSubDivKVValues( Xi, 1);
[B,Xi]=RefineKnotSolidXi( B,p,Xi,X_ );
[ E_ ] = getSubDivKVValues( Eta, 1);
[B,Eta]=RefineKnotSolidEta( B,q,Eta,E_ );
BT(2).B = B;
KVT(2).Xi = Xi;
KVT(2).Eta = Eta;
degT(2).p = p;
degT(2).q = q;

% Patch 3 下 3*3*2
Xi = [0,0,0,1,1,1];
Eta = [0,0,0,1,1,1];
k_ = length(Xi);
l_ = length(Eta);
B = cell(3,3);
B{1,1} = [d 0 0 1];
B{2,1} = [d d/2 0 1];
B{3,1} = [d d 0 1];
B{1,2} = [d*3/4 d/4 0 1];
B{2,2} = [d*3/4 d/2 0 1];
B{3,2} = [d*3/4 d*3/4 0 1];
B{1,3} = [d-a a 0 1];
B{2,3} = [d-a+r1/sqrt(2) d/2 0 1/sqrt(2)];
B{3,3} = [d-a d-a 0 1];
n = size(B,1);
m = size(B,2);
p = k_-n-1;
q = l_-m-1;
[ X_ ] = getSubDivKVValues( Xi, 1);
[B,Xi]=RefineKnotSolidXi( B,p,Xi,X_ );
[ E_ ] = getSubDivKVValues( Eta, 1);
[B,Eta]=RefineKnotSolidEta( B,q,Eta,E_ );
BT(3).B = B;
KVT(3).Xi = Xi;
KVT(3).Eta = Eta;
degT(3).p = p;
degT(3).q = q;

% Patch 4 左 3*3*2
Xi = [0,0,0,1,1,1];
Eta = [0,0,0,1,1,1];
k_ = length(Xi);
l_ = length(Eta);
B = cell(3,3);
B{1,1} = [0 0 0 1];
B{2,1} = [d/2 0 0 1];
B{3,1} = [d 0 0 1];
B{1,2} = [d/4 d/4 0 1];
B{2,2} = [d/2 d/4 0 1];
B{3,2} = [d*3/4 d/4 0 1];
B{1,3} = [a a 0 1];
B{2,3} = [d/2 a-r1/sqrt(2) 0 1/sqrt(2)];
B{3,3} = [d-a a 0 1];
n = size(B,1);
m = size(B,2);
p = k_-n-1;
q = l_-m-1;
[ X_ ] = getSubDivKVValues( Xi, 3);
[B,Xi]=RefineKnotSolidXi( B,p,Xi,X_ );
[ E_ ] = getSubDivKVValues( Eta, 3);
[B,Eta]=RefineKnotSolidEta( B,q,Eta,E_ );
BT(4).B = B;
KVT(4).Xi = Xi;
KVT(4).Eta = Eta;
degT(4).p = p;
degT(4).q = q;

clear
clc;
addpath(genpath("../subcode"))
% Load data
data_plate_with_hole_2D;

%% parameters
nelT = 0;
nnpT = 0;
IENT = [];
for ipatch = 1:length(BT)
    KV = KVT(ipatch);
    Xi = KV.Xi; Eta = KV.Eta;
    B = BT(ipatch).B;
    deg = degT(ipatch);
    
    [ X_ ] = getSubDivKVValues( Xi, 1);
    [B,Xi]=RefineKnotSolidXi( B,deg.p,Xi,X_ );
    [ E_ ] = getSubDivKVValues( Eta, 1);
    [B,Eta]=RefineKnotSolidEta( B,deg.q,Eta,E_ );

    KVT(ipatch).Xi = Xi;
    KVT(ipatch).Eta = Eta;

    BT(ipatch).B = B;
    
    % Number of control points after refinement
    n = size(B,1);
    m = size(B,2);
    
    % Build connectivity arrays
    nel = (n-deg.p) * (m-deg.q); % number of elements
    nnp = n*m; % number of global basis functions
    nen = (deg.p+1)*(deg.q+1); % number of local basis functions
    ndof = nnp*2; % number of global degrees of freedom
    ldof = nen*2; % number of local degrees of freedom
    [INN,IEN] = BldINCIEN_2d( deg,n,m );
    Con(ipatch).nel = nel;
    Con(ipatch).nen = nen;
    Con(ipatch).INN = INN;
    Con(ipatch).IEN = IEN;
    Con(ipatch).ndof = ndof;
    
    nelT = nelT + nel;
    IENT = [IENT IEN+nnpT];
    nnpT = nnpT + nnp;
end
% plotNurbsSolidMulti(KVT,BT)
ID = reshape(1:max(max(IENT))*2,2,max(max(IENT)));
LM = zeros(2*nen,nelT);
for i = 1 : nelT
    LM(:,i)=reshape(ID(:,IENT(:,i)),2*nen,1);
end

% Material parameters:
E_Y = 2.06e5;
nu_P = 0.3;
denisty = 7.85e-9;
D=hooke_strain(1,E_Y,nu_P);

% Gauss-Legendre quadrature points: 
[ gp_x,w_x ] = getGP( deg.p );     
[ gp_y,w_y ] = getGP( deg.q );
NQUADx = size(gp_x,2);
NQUADy = size(gp_y,2);

% Dynamic problem parameters
dt = 1e-5; % Time step
t_end = 1e-3; % The final time
nt = floor(t_end/dt); % Time steps

%% Stiffness matrix and load vector computation
ndof = nnpT*2;
K = sparse(ndof,ndof); % Needs to be changed to sparse for large problems!!
M = sparse(ndof,ndof);
C = sparse(ndof,ndof);
F = sparse(ndof,nt+1);
e0 = 0;
for ipatch = 1:length(BT)
    KV = KVT(ipatch);
    B = BT(ipatch).B;
    deg = degT(ipatch);
    nel = Con(ipatch).nel;
    nen = Con(ipatch).nen;
    INN = Con(ipatch).INN;
    IEN = Con(ipatch).IEN;
    
    % Gauss-Legendre quadrature points:
    [ gp_x,w_x ] = getGP( deg.p );
    [ gp_y,w_y ] = getGP( deg.q );
    NQUADx = size(gp_x,2);
    NQUADy = size(gp_y,2);
    
    for e = 1 : nel
        % NURBS coordinates; convention consistent with Algorithm 7 in Hughes
        ni = INN(IEN(1,e),1);
        nj = INN(IEN(1,e),2);
        
        % Check if element has zero measure
        if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj))
            continue
        end
        
        KTe = zeros(nen*2);
        
        for i = 1 : NQUADx % Loop trough Gauss points
            for j = 1 : NQUADy
                    % Gauss point
                    GP.xi_tilde = gp_x(i);
                    GP.eta_tilde = gp_y(j);
                    
                    % Get Basis, derivatives, and det(J) for current gauss pt
                    [ R,dR_dx,Jdet ] = Shape_function_2d( GP,e,deg,B,KV,INN,IEN);
                    
                    % Combine quadrature weights with det(J)
                    Jmod = abs(Jdet)*w_x(i)*w_y(j);
                    
                    % Build KTe
                    [ KTe_,kinmtx ] = Build_K_Local_2d( dR_dx,Jmod,D,nen );
                    KTe = KTe + KTe_;
            end
        end
        Me = denisty*eye(ldof);
        % Global Assembly
        idx = LM(:,e0+e)';
        K(idx,idx) = K(idx,idx) + KTe;
        M(idx,idx) = M(idx,idx) + Me;
    end
    e0 = e0 + nel;
end

%% Dirichlet boundary
% patch 1
constNod = [];
inc = 0;

ipatch = 1;
B = BT(ipatch).B;
INN = Con(ipatch).INN;
loc_x = 0;
for i = 1:numel(B)
    if B{i}(1)==loc_x
        constNod=[constNod i+inc];
    end
end
bc1=reshape(ID(:,constNod),numel(ID(:,constNod)),1);

for i=1:length(bc1)
    c = bc1(i);
    K(c,:) = 0;M(c,:) = 0;
    K(:,c) = 0;M(:,c) = 0;
    K(c,c) = 1;M(c,c) = 1;
end

%% load
% patch 3
constNod = [];
inc = 0;
for ipatch = 1:2
    inc = inc + Con(ipatch).ndof; %
end
ipatch = 3;
KV = KVT(ipatch);
B = BT(ipatch).B;
deg = degT(ipatch);
nel = Con(ipatch).nel;
nen = Con(ipatch).nen;
INN = Con(ipatch).INN;
IEN = Con(ipatch).IEN;
loc_x = 4;
for i = 1:numel(B)
    if B{i}(1)==loc_x
        constNod=[constNod i];
    end
end
kum =0;
NeuEle = [];
for e = 1:nel
    sameNod = intersect(IEN(:, e), constNod); 
    if length(sameNod) == deg.q+1
        kum = kum+1;
        NeuEle = [NeuEle e];
        Neu(:, kum) = sameNod;     
    end   
end
for ie = 1: size(NeuEle,2)
    e = NeuEle(1, ie);
    ni = INN(IEN(1,e),1);
    nj = INN(IEN(1,e),2);
    
    % Check if element has zero measure
    if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj))
        continue
    end
    Fe = zeros(nen*2,1);
    for j = 1 : NQUADy
        % Gauss point
        GP.xi_tilde = 1;
        GP.eta_tilde = gp_y(j);
        [ R,dR_dx,Jdet ] = Shape_function_2d_1( GP,e,deg,B,KV,INN,IEN,1);
        % Combine quadrature weights with det(J)
        Jmod = abs(Jdet)*w_y(j);
        Px = 1;
        Py = 0;
        for t = 1:size(R,1)
            cR = R(t);
            scrt((2*t-1) : (2*t)) = [2*IEN(t, e)-1, 2*IEN(t, e)];
            Fe(2*t-1) = Fe(2*t-1) + Px * cR * Jmod;
            Fe(2*t) = Fe(2*t) + Py * cR * Jmod;
        end
    end
    F(scrt+inc,:) = F(scrt+inc,:) + Fe;
end


%% 
BB = [];
for ipatch = 1:length(BT)
    B = BT(ipatch).B;
    for i = 1:numel(B)
        BB = [BB;B{i}'];
    end
end
rep = [];
for i = 2:size(BB,1)
    for j = 1:i-1
        if BB(i,1)==BB(j,1) && BB(i,2)==BB(j,2) && BB(i,3)==BB(j,3) && BB(i,4)==BB(j,4)
            rep = [rep;i,j];
            break;
        end
    end
end
T = eye(ndof,ndof);
for i = size(rep,1):-1:1
    T(rep(i,1),rep(i,2)) = eye(1,1);
    T(:,rep(i,1)) = [];
end

K = T'*K*T;
M = T'*M*T;
C = T'*C*T;
F = T'*F;

acc = zeros(size(F,1),nt+1); % acceleration
vel = zeros(size(F,1),nt+1); % velocity
d = zeros(size(F,1),nt+1); % displacement

t1 = cputime;
[d,vel,acc] = Newmark(K,M,C,F,d,vel,acc,dt,nt);
t2 = cputime;
disp(['FOM timecost ' num2str(t2-t1)]);
dsp = T*d;

%% POD
L = 20;
r = 10;
snapshots_d = d(:,1:L);
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);

[U,~,~]=svd(snapshots_d);
phy = U(:,1:r);
t3 = cputime;
[d_r,vel_r,acc_r] = Newmark_POD(K,M,C,F,d,vel,acc,dt,nt,...
    phy,snapshots_d,snapshots_v,snapshots_a);
t4 = cputime;
disp(['ROM timecost ' num2str(t4-t3)]);
dsp_r = T*d_r;

%% point figure
% for ipatch = 1:4
%     B = BT(ipatch).B;
% for i = 1:numel(B)
%     if (B{i}(1)==4 && B{i}(2)==0)
%         x_dof = i*2-1;
%     end
% end
% end
% figure(4);
% plot(0:dt:t_end,dsp(x_dof,:),'-',...
%     0:dt:t_end,dsp_r(x_dof,:),'--')
% plot(0:dt:t_end,dsp(x_dof,:))
figure(5);
for i = 1 : ndof
    plot(0:dt:t_end,dsp(i,:),'-',...
    0:dt:t_end,dsp_r(i,:),'--')
pause(0.01)
end
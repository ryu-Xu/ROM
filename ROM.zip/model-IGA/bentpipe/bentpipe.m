clc;
clear;
close all;

addpath(genpath('../subcode'));

% Load initial data
data_bentpipe;
deg.p = p; deg.q=q; deg.r = r;
[ X_ ] = getSubDivKVValues( Xi, 2);
[B,Xi]=RefineKnotSolidXi( B,deg.p,Xi,X_ );
[ E_ ] = getSubDivKVValues( Eta, 2);
[B,Eta]=RefineKnotSolidEta( B,deg.q,Eta,E_ );
[ Z_ ] =getSubDivKVValues( Zeta, 2);
[B,Zeta]=RefineKnotSolidZeta( B,deg.r,Zeta,Z_ );

KV.Xi =Xi; KV.Eta = Eta; KV.Zeta = Zeta;
plotNurbsSolidElementSimple( KV, B )
axis equal

% Number of weights
n = size(B,1);
m = size(B,2);
l = size(B,3);

KV.Xi =Xi; KV.Eta = Eta; KV.Zeta = Zeta;
% plotNurbsSolidElementSimple( KV, B )
% axis equal

% Build connectivity arrays
nel = (n-deg.p) * (m-deg.q) * (l-deg.r); % number of elements
nnp = n*m*l; % number of global basis functions
nen = (deg.p+1)*(deg.q+1)*(deg.r+1); % number of local basis functions
ndof = nnp*3; % number of global degrees of freedom
ldof = nen*3; % number of local degrees of freedom
[INN,IEN] = BldINCIEN( deg,n,m,l );
ID = reshape(1:max(max(IEN))*3,3,max(max(IEN)));
LM = zeros(3*nen,nel);
for i = 1 : nel
    LM(:,i)=reshape(ID(:,IEN(:,i)),3*nen,1);
end

% Material parameters:
E_Y = 2.06e5;
nu_P = 0.3;
denisty = 7.85e-9;
D=hooke_strain(5,E_Y,nu_P);

% Gauss-Legendre quadrature points: 
[ gp_x,w_x ] = getGP( deg.p );     
[ gp_y,w_y ] = getGP( deg.q );
[ gp_z,w_z ] = getGP( deg.r );
NQUADx = size(gp_x,2);
NQUADy = size(gp_y,2);
NQUADz = size(gp_z,2);

% Dynamic problem parameters
dt = 1e-3; % Time step
t_end = 5e-1; % The final time
nt = floor(t_end/dt); % Time steps

%% Stiffness matrix and load vector computation
K = sparse(ndof,ndof); % Needs to be changed to sparse for large problems!!
M = sparse(ndof,ndof);
C = sparse(ndof,ndof);
F = sparse(ndof,nt+1);
for e = 1 : nel
    % NURBS coordinates; convention consistent with Algorithm 7 in Hughes
    ni = INN(IEN(1,e),1);
    nj = INN(IEN(1,e),2);
    nk = INN(IEN(1,e),3);
    
    % Check if element has zero measure
    if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj)) || (KV.Zeta(nk+1) == KV.Zeta(nk))
        continue
    end
    
    Ke = zeros(nen*3);
    
    for i = 1 : NQUADx % Loop trough Gauss points
        for j = 1 : NQUADy
            for k = 1 : NQUADz
                % Gauss point
                GP.xi_tilde = gp_x(i);
                GP.eta_tilde = gp_y(j);
                GP.zeta_tilde = gp_z(k);
                
                % Get Basis, derivatives, and det(J) for current gauss pt
                [ R,dR_dx,Jdet ] = Shape_function( GP,e,deg,B,KV,INN,IEN);
                
                % Combine quadrature weights with det(J)
                Jmod = abs(Jdet)*w_x(i)*w_y(j)*w_z(k);
                
                % Build Ke
                [ Ke_,kinmtx ] = Build_K_Local( dR_dx,Jmod,D,nen );
                Ke = Ke + Ke_;
            end
        end
    end
    Me = denisty*eye(ldof);
    % Global Assembly
    idx = LM(:,e)';
    K(idx,idx) = K(idx,idx) + Ke;
    M(idx,idx) = M(idx,idx) + Me;
end

%% load
loc_z = 4;
constNod = [];
for i = 1:numel(B)
    if B{i}(3)==loc_z
        constNod=[constNod i];
    end
end
kum =0;
NeuEle = [];
for e = 1:nel
    sameNod = intersect(IEN(:, e), constNod); 
    if length(sameNod) == (p+1)*(q+1)
        kum = kum+1;
        NeuEle = [NeuEle e];
        Neu(:, kum) = sameNod;     
    end   
end
for ie = 1: size(NeuEle,2)
    e = NeuEle(1, ie);
    ni = INN(IEN(1,e),1);
    nj = INN(IEN(1,e),2);
    nk = INN(IEN(1,e),3);
    
    % Check if element has zero measure
    if (KV.Xi(ni+1) == KV.Xi(ni)) || (KV.Eta(nj+1) == KV.Eta(nj)) || (KV.Zeta(nk+1) == KV.Zeta(nk))
        continue
    end
    
    Fe = zeros(nen*3,1);
    for i = 1 : NQUADx % Loop trough Gauss points
        for j = 1 : NQUADy
            % Gauss point
            GP.xi_tilde = gp_x(i);
            GP.eta_tilde = gp_y(j);
            GP.zeta_tilde = -1;
            [ R,dR_dx,Jdet ] = Shape_function_1( GP,e,deg,B,KV,INN,IEN,3); 
            % Combine quadrature weights with det(J)
            Jmod = abs(Jdet)*w_x(i)*w_y(j);
            Px = 0;
            Py = 0;
            Pz = -10;
            for t = 1:size(R,1)
                cR = R(t);
                scrt((3*t-2) : (3*t)) = [3*IEN(t, e)-2, 3*IEN(t, e)-1, 3*IEN(t, e)];
                Fe(3*t-2) = Fe(3*t-2) + Px * cR * Jmod;
                Fe(3*t-1) = Fe(3*t-1) + Py * cR * Jmod;
                Fe(3*t) = Fe(3*t) + Pz * cR * Jmod;
            end          
        end
    end
    F(scrt,:) = F(scrt,:) + Fe;
end

%% Boundary conditions
loc_x = 3;
constNod = [];
for i = 1:numel(B)
    if B{i}(1)==loc_x
        constNod=[constNod i];
    end
end

bc1=reshape(ID(:,constNod),numel(ID(:,constNod)),1);

nbc = length(bc1);
for i = 1:nbc
    c = bc1(i);
    K(c,:) = 0;M(c,:) = 0;
    K(:,c) = 0;M(:,c) = 0;
    K(c,c) = 1;M(c,c) = 1;
end

%% Solve system
rep = [];
for i = 2:numel(B)
    for j = i-1:-1:1
        if B{i}(1)==B{j}(1) && B{i}(2)==B{j}(2) && B{i}(3)==B{j}(3) && B{i}(4)==B{j}(4)
            rep = [rep;i,j];
        end
    end
end
T = eye(ndof,ndof);
for i = size(rep,1):-1:1
    T(3*rep(i,1)-2:3*rep(i,1),3*rep(i,2)-2:3*rep(i,2)) = eye(3,3);
    T(:,3*rep(i,1)-2:3*rep(i,1)) = [];
end
K = T'*K*T;
M = T'*M*T;
C = T'*C*T;
F = T'*F;
acc = zeros(size(F,1),nt+1); % acceleration
vel = zeros(size(F,1),nt+1); % velocity
d = zeros(size(F,1),nt+1); % displacement

t1 = cputime;
[d,vel,acc] = Newmark(K,M,C,F,d,vel,acc,dt,nt);
t2 = cputime;
disp(['FOM timecost ' num2str(t2-t1)]);
dsp = T*d;

%% POD
L = 20;
r = 10;
snapshots_d = d(:,1:L);
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);

[U,~,~]=svd(snapshots_d);
phy = U(:,1:r);
t3 = cputime;
[d_r,vel_r,acc_r] = Newmark_POD(K,M,C,F,d,vel,acc,dt,nt,...
    phy,snapshots_d,snapshots_v,snapshots_a);
t4 = cputime;
disp(['ROM timecost ' num2str(t4-t3)]);
dsp_r = T*d_r;


%% post processing
gcoord=zeros(nnp,3);
for i=1:nnp
    gcoord(i,:)=B{i}(1:3);
end
A = 0; e=0; 
for k = 1 : l
    for j = 1 : m
        for i = 1 : n
            A = A + 1;
            if i >= (1+1) && j >= (1+1) && k >= (1+1)
                e = e + 1;
                for kloc = 0 : 1
                    for jloc = 0 : 1
                        for iloc = 0 : 1
                            B_ = A - kloc*n*m- jloc*n - iloc; % global function number
                            b = kloc*(1+1)*(1+1) + jloc*(1+1)+ iloc + 1; % local function number
                            BR(b,e) = B_; % assign connectivity
                        end
                    end
                end
            end
        end
    end
end
BR1=BR;
BR1(1,:)=BR(2,:);
BR1(2,:)=BR(1,:);
BR1(5,:)=BR(6,:);
BR1(6,:)=BR(5,:);

% Replace repeat control points
repcon = n:n:n*m*l;
for i1 = 1:size(BR1,1)*size(BR1,2)
    for i2 = 1:length(repcon)
      if BR1(i1)==repcon(i2)
            BR1(i1) = BR1(i1)-n+1;
      end
   end
end

dsp_t = full(dsp(:,nt));
dsp_t_r = full(dsp_r(:,nt));
el2 = norm(dsp_t-dsp_t_r,2)/norm(dsp_t,2);

% Tecplot Cloud Atlas
name1 = 'disp.plt';
name2 = 'dispr.plt';
tecplotdisp(BR1,gcoord,dsp_t,name1);
tecplotdisp(BR1,gcoord,dsp_t_r,name2);

% line figure
line_ab = [];
line_bc = [];
line_de = [];
for i = 1:numel(B)
    if (B{i}(2)==0 && B{i}(3)==4 && B{i}(1)>=-2 && B{i}(1)<=-1)
        line_ab = [line_ab,i];
    elseif (B{i}(2)==0 && B{i}(1)==-2 && B{i}(3)>=1 && B{i}(3)<=4)
        line_bc = [line_bc,i];
    elseif ((B{i}(1)==0 && B{i}(3)==4 && B{i}(2)>=1 && B{i}(2)<=2))
        line_de = [line_de,i];
    end
end

figure(1);
plot(-2:1/(size(line_ab,2)-1):-1,dsp(3*line_ab,nt),'*-',...
    -2:1/(size(line_ab,2)-1):-1,dsp_r(3*line_ab,nt),'o--')
figure(2);
plot(1:3/(size(line_bc,2)-1):4,dsp(3*line_bc,nt),'*-',...
    1:3/(size(line_bc,2)-1):4,dsp_r(3*line_bc,nt),'o--')
figure(3);
plot(1:1/(size(line_de,2)-1):2,dsp(3*line_de,nt),'*-',...
    1:1/(size(line_de,2)-1):2,dsp_r(3*line_de,nt),'o--')


% point figure
for i = 1:numel(B)
    if (B{i}(1)==-2 && B{i}(2)==0 && B{i}(3)==4)
        z_dof = i*3;
    end
end
figure(4);
plot(0:dt:t_end,dsp(z_dof,:),'-',...
    0:dt:t_end,dsp_r(z_dof,:),'o--')
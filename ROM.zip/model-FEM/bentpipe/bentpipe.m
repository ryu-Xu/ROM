
clear
addpath(genpath('../subcode'));
%---------------------
%  ����ڵ�͵�Ԫ
%---------------------
tic
nodes_data=dlmread('n22.txt',',');
elements=dlmread('e22.txt',',');

%---------------
%  input super parameters
%---------------
gcoord=nodes_data(:,2:4);
nodes=elements(:,2:5);
nnode=size(gcoord,1);
nel=size(nodes,1);
nnel=size(nodes,2);%
ndof=3;%ÿ���ڵ����ɶ���
sdof=nnode*ndof;%ϵͳ�����ɶ���
edof=nnel*ndof;%ÿ����Ԫ���ɶ���
nh = 4;%Hammer��ֵ���ֵ���


elastic=2.1e5;%����ģ������λMPa��N/mm2
poisson=0.30;%���ɱ�
damping=0;%����ϵ��
density=7.85e-9;%�ܶȣ���λtonne/mm2

%�߽�����
bcdof=zeros(sdof,1);
fpos = [];%�غ����ɶ�
for i = 1:size(gcoord,1)
    inx = gcoord(i,1);
    iny = gcoord(i,2);
    inz = gcoord(i,3);
    %%%Լ��
    
    if iny == -80
        bcdof(3*i-2) = 1;
        bcdof(3*i-1) = 1;
        bcdof(3*i) = 1;
    elseif inx == 60
        fpos = [fpos, 3*i-2];%�غ����ɶ�
    end

end

%-----------------------------------------
% ��ʼ����������
%-----------------------------------------

kk=sparse(sdof,sdof);%����նȾ���Ŀվ���
mm=sparse(sdof,sdof);%����������
cc=sparse(sdof,sdof);%���������

[Pc,Ww] = jf_c3d10;  % sampling points & weights
D=Dc(4,elastic,poisson);%���Ծ���

t1 = toc;
%-----------------------------------------
% ����նȾ�����װ
%-----------------------------------------
for iel=1:nel               % loop for the total number of elements

    nd=nodes(iel,:);         % extract connected node for (iel)-th element
xcoord = gcoord(nd,1);
ycoord = gcoord(nd,2);
zcoord = gcoord(nd,3);

k=zeros(edof,edof);         % initialization of element matrix to zero
m=zeros(edof,edof);
c=zeros(edof,edof);
%--------------------------------
%  ��ֵ����
%--------------------------------

for inh=1:nh
L1=Pc(inh,1);                  % sampling point in x-axis
L2=Pc(inh,2);
L3=Pc(inh,3);
L4=Pc(inh,4);

[shape,dndl1,dndl2,dndl3,dndl4]=shape_c3d4(L1,L2,L3,L4); % compute shape functions and
                                      % derivatives at sampling point

jacob3=j_c3d4(nnel,dndl1,dndl2,dndl3,dndl4,xcoord,ycoord,zcoord);  % compute Jacobian

detjacob=1/6*det(jacob3);                 % determinant of Jacobian
invjacob=inv(jacob3);                 % inverse of Jacobian matrix

[dndx,dndy,dndz]=jj_c3d4(dndl1,dndl2,dndl3,dndl4,invjacob); % derivatives w.r.t.
                                               % physical coordinate
B=Bc_c3d4(nnel,dndx,dndy,dndz);
%------------------------------
%  ���㵥Ԫ����
%------------------------------

k=k+B'*D*B*Ww*detjacob;
m=m+density*(shape'*shape)*Ww*detjacob;
                                % end of numerical integration loop
end

index=feeldof(nd,nnel,ndof);% extract system dofs associated with element

%----------------------------------
% ��װ����
%----------------------------------

kk=feasmbl1(kk,k,index);    
mm=feasmbl1(mm,m,index);  % assemble element matrices 
% cc=feasmbl1(cc,c,index);
end                        % end of element loops


t2 = toc;
disp("�նȾ�����װ���")
%----------------------------------
% ���
%----------------------------------

dt = 1e-8;

nt=400;
timesteps=0:dt:nt*dt;

q0=zeros(sdof,1);
dq0=zeros(sdof,1);

fd=zeros(sdof,nt);%

fd(fpos,:) = -1e7/length(fpos);
%%----------------------------------------------
tic
[acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0);%newmark
t3 = toc;
%% POD
L = 20;%˲�����
snapshots_d = dsp(:,1:L);%ȡǰ20��ʱ�䲽��Ϊ˲��
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);
[U,~,~] = svd(snapshots_d);
% r = POD_jieduan(S,0.99999);
r = 10;%������
phy = U(:,1:r);%ȡǰr����Ϊ��
tic
[~,~,dsp_r]=NewmarkPOD(kk,cc,mm,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a);
t4 = toc;
%% plot
% for point =1:sdof
% plot(timesteps, dsp_r(point,:),'*',timesteps,dsp(point,:),'-')%չʾȫ��ʱ��Ľ��
% xlabel('Time(seconds)')
% ylabel(' displ. (mm)')
% legend('POD','FEM')
% pause(0.01)
% end 

%----------------------------------
% ����
%----------------------------------
% %��һ����ab Y��
yy = 20:1:40;
xx = 60*ones(1,length(yy));
zz = zeros(1,length(yy));
line_ab = [xx;yy;zz]';
% %�ڶ�����cd X��
xx = 0:1:60;
yy = 40*ones(1,length(xx));
zz = zeros(1,length(xx));
line_cd = [xx;yy;zz]';
%��������ef Z��
zz = 20:1:40;%��Ϊ�ǶԳƵ�
xx = 60*ones(1,length(zz));
yy = zeros(1,length(zz));
line_ef = [xx;yy;zz]';
% 
% [I200a,IR200a] = lineplot_wg(nt/2,line_ab,nel,gcoord,dsp,dsp_r,nodes);
[I400a,IR400a] = lineplot_wg(nt,line_ab,nel,gcoord,dsp,dsp_r,nodes);
% 
% [I200c,IR200c] = lineplot_wg(nt/2,line_cd,nel,gcoord,dsp,dsp_r,nodes);
[I400c,IR400c] = lineplot_wg(nt,line_cd,nel,gcoord,dsp,dsp_r,nodes);
% 
% [I200e,IR200e] = lineplot_wg(nt/2,line_ef,nel,gcoord,dsp,dsp_r,nodes);
[I400e,IR400e] = lineplot_wg(nt,line_ef,nel,gcoord,dsp,dsp_r,nodes);
% % 
% % save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200.mat'],'I200a');
% % save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200r.mat'],'IR200a');
save(['I400ab.mat'],'I400a');
save(['IR400ab.mat'],'IR400a');
% 
% save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200.mat'],'I200c');
% % save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200r.mat'],'IR200c');
save(['I400bc.mat'],'I400c');
save(['IR400bc.mat'],'IR400c');
% 
% save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200.mat'],'I200e');
% save(['E:\tables_old\table1226\code\data\output\E\��ͼ\','w11x200r.mat'],'IR200e');
save(['I400de.mat'],'I400e');
save(['IR400de.mat'],'IR400e');

% 
% % %----------------------------------
% % % ������������ͼ
% % % %----------------------------------
dsp_x = dsp(1:3:end,:);
dsp_y = dsp(2:3:end,:);
dsp_z = dsp(3:3:end,:);
% 
% % 
% % dsp_x = dsp_r(1:3:end,:);
% % dsp_y = dsp_r(2:3:end,:);
% % dsp_z = dsp_r(3:3:end,:);
% % 
for it = 200:100:400
    
    time=(it-0)*dt;%ʱ��
    
filename=['figure',num2str(it,'%02.f'),'.plt'];
% filename = 'HEAT_fem_2D.plt';
title='';%�ޱ���
variables={'X','Y','Z','DISP-X','DISP-Y','DISP-Z'};
zone_title='';%�ޱ���
Mat_Data=[gcoord(:,1),gcoord(:,2),gcoord(:,3)...
    dsp_x(:,it),dsp_y(:,it),dsp_z(:,it)];
 
%2�����ļ�
if exist(filename,'file') 
    delete(filename)
end
f_id=fopen(filename,'a');
fclose(f_id);

%3�����ļ�ͷ
plt_Head(filename,title,variables)
%4����zone��point����ʽ,�Ǳ�׼����
plt_Z(filename,zone_title,time,Mat_Data,nodes)

end




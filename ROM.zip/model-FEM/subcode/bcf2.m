function[ff]=bcf2(bcdof,ff)
% ʩ�ӱ߽�����
% nbc  = length(bcdof);
% bcval ��Ϊ0�����
% for i=1:nbc
%     o = 1;
%     for j=ndof*(bcdof(i)-1)+1:ndof*bcdof(i)
%         ff(j)=bcval(i,o);
%         o = o+1;
%     end
% end
%

%bcval��Ϊ0
% ff(find(bcdof==1))=0;
nbc  = length(bcdof);
for i=1:nbc
    if bcdof(i) == 1
        ff(i)=0;
    end
end
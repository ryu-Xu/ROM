function [dsp_uv,dsp_uv_r] = lineplot_wg(tt,line_set,nel,gcoord,dsp,dsp_r,nodes)

%% tt Ϊ���õ�ʱ��
% xx,yy������
% �����Ҫ��Ϊ�˻���λ��������ı仯����
% �κ��������


n = size(line_set,1);

dsp_uv_r = zeros(3,n);
dsp_uv = zeros(3,n);

for ii = 1:n
    ixx = line_set(ii,1);
    iyy = line_set(ii,2);
    izz = line_set(ii,3);
    p_detected = [ixx,iyy,izz];
    for ie = 1:nel
        nd = nodes(ie,:);
        xcoord = gcoord(nd,1);
        ycoord = gcoord(nd,2);
        zcoord = gcoord(nd,3);
        point_set = [xcoord,ycoord,zcoord];
        if inpolyhedron(point_set,p_detected)
            %��ȡuuvv��uuvv_r
            uuvv_r = dsp_r(reshape([nd*3-2;nd*3-1;nd*3],12,1),tt);
            uuvv = dsp(reshape([nd*3-2;nd*3-1;nd*3],12,1),tt);

            %��ù�������
            beta = shape_q4_3d(point_set,uuvv);
            beta_r = shape_q4_3d(point_set,uuvv_r);
            
            shape = [1,ixx,iyy,izz,0,0,0,0,0,0,0,0
                0,0,0,0,1,ixx,iyy,izz,0,0,0,0
                0,0,0,0,0,0,0,0,1,ixx,iyy,izz];
            
            dsp_uv_r(:,ii) = shape*beta_r;
            dsp_uv(:,ii) = shape*beta;
            break
        end
    end
end
end
function [dndx,dndy,dndz]=jj_c3d4(dndl1,dndl2,dndl3,dndl4,invjacob)

%------------------------------------------------------------------------
%  Purpose:
%     determine derivatives of 2-D isoparametric shape functions with 
%     respect to physical coordinate system
%
%  Synopsis:
%     [dhdx,dhdy]=federiv2(nnel,dhdr,dhds,invjacob)  
%
%  Variable Description:
%     dhdx - derivative of shape function w.r.t. physical coordinate x
%     dhdy - derivative of shape function w.r.t. physical coordinate y
%     nnel - number of nodes per element   
%     dhdr - derivative of shape functions w.r.t. natural coordinate r
%     dhds - derivative of shape functions w.r.t. natural coordinate s
%     invjacob - inverse of 2-D Jacobian matrix
%------------------------------------------------------------------------
zz = [0 0 0
    1 0 0
    0 1 0
    0 0 1];
dndl = [dndl1,dndl2,dndl3,dndl4];
dndxyz = dndl*(invjacob*zz);
dndx = dndxyz(:,1);
dndy = dndxyz(:,2);
dndz = dndxyz(:,3);
end

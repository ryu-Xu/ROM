function J = j_c3d4(nnel,dndl1,dndl2,dndl3,dndl4,xcoord,ycoord,zcoord)
  % c3d4 �ſɱȾ���
  J = zeros(4,4);
  J(1,:) = 1;
  for i = 1:nnel
      
        J(2,1) = xcoord(i)*dndl1(i) + J(2,1);
        J(3,1) = ycoord(i)*dndl1(i) + J(3,1);
        J(4,1) = zcoord(i)*dndl1(i) + J(4,1);
        
        J(2,2) = xcoord(i)*dndl2(i) + J(2,2);
        J(3,2) = ycoord(i)*dndl2(i) + J(3,2);
        J(4,2) = zcoord(i)*dndl2(i) + J(4,2);
        
        J(2,3) = xcoord(i)*dndl3(i) + J(2,3);
        J(3,3) = ycoord(i)*dndl3(i) + J(3,3);
        J(4,3) = zcoord(i)*dndl3(i) + J(4,3);
        
        J(2,4) = xcoord(i)*dndl4(i) + J(2,4);
        J(3,4) = ycoord(i)*dndl4(i) + J(3,4);
        J(4,4) = zcoord(i)*dndl4(i) + J(4,4);
  end

end

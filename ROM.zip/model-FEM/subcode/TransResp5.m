function [acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0)
%--------------------------------------------------------------------------
%  Purpose:
%     The function subroutine TransResp5.m calculates transient response of
%     a structural system using Newmark integration scheme.
%  Synopsis:
%     [acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0)
%  Variable Description:
%     Input parameters
%       kk, cc, mm - stiffness, damping and mass matrices
%       fd - Input or forcing influence matrix
%       bcdof - Boundary condition dofs vector
%       nt - Number of time steps
%       dt - Time step size
%       q0, dq0 - Initial condition vectors
%     Output parameters
%       acc - Acceleration response
%       vel - Velocity response
%       dsp - Displacement response
%--------------------------------------------------------------------------
%  (1) initial condition
%--------------------------------------------------------------------------
sdof=size(kk,1);
dsp=zeros(sdof,nt);                                         % displacement matrix
vel=zeros(sdof,nt);                                             % velocity matrix
acc=zeros(sdof,nt);                                          % acceleration matrix
dsp(:,1)=q0;                                               % initial displacement
vel(:,1)=dq0;                                                  % initial velocity
alpha=0.8; beta=0.7;                                        % select the parameters
%--------------------------------------------------------------------------
%  (2) Newmark integration scheme for time integration
%--------------------------------------------------------------------------
acc(:,1)=mm\(fd(:,1)-kk*dsp(:,1)-cc*vel(:,1));% compute the initial acceleration (t=0)
ekk=kk+mm/(alpha*dt^2)+cc*beta/(alpha*dt);% compute the effective stiffness matrix
ekk = bck2(bcdof,ekk);% Boundary condition
dsp(find(bcdof==1),:) = 0;
vel(find(bcdof==1),:) = 0;
acc(find(bcdof==1),:) = 0;
for it=1:nt % loop for each time step
  cfm=dsp(:,it)/(alpha*dt^2)+vel(:,it)/(alpha*dt)+acc(:,it)*(0.5/alpha-1);
  cfc=dsp(:,it)*beta/(alpha*dt)+vel(:,it)*(beta/alpha-1)...
     +acc(:,it)*(0.5*beta/alpha-1)*dt;
  efd=fd(:,it)+mm*cfm+cc*cfc;%  compute the effective force vector
  efd = bcf2(bcdof,efd);
  dsp(:,it+1)=ekk\efd;                        % find the displacement at time t+dt
  acc(:,it+1)=(dsp(:,it+1)-dsp(:,it))/(alpha*dt^2)-vel(:,it)/(alpha*dt)...
              -acc(:,it)*(0.5/alpha-1);              % find the acceleration at time t+dt
  vel(:,it+1)=vel(:,it)+acc(:,it)*(1-beta)*dt+acc(:,it+1)*beta*dt;% find the velocity at time t+dt
end
disp('The method is Newmark integration')
end

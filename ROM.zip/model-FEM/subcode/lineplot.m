% tt Ϊ���õ�ʱ��
% xx,yy������
% �����Ҫ��Ϊ�˻���λ��������ı仯����
% �κ��������

% xx1 = -4:0.1:-1;
% xx2 = 1:0.1:4;
% xx3 = -0.9:0.1:0.9;
% xx = [xx1,xx2,xx3];
% yy = [zeros(1,length([xx1,xx2])),sqrt(1.0-xx3.^2)];

yy = -4:0.1:4;
xx = 4*ones(1,length(yy));

tt = nt/2;
dsp_uv_r = zeros(2,length(xx));
dsp_uv = zeros(2,length(xx));
for ii = 1:length(xx)
    ixx = xx(ii);
    iyy = yy(ii);
    for ie = 1:nel
        nd = nodes(ie,:);
        xcoord = gcoord(nd,1);
        ycoord = gcoord(nd,2);

        if inpolygon(ixx,iyy,xcoord,ycoord)
            %��ȡuuvv��uuvv_r
            uuvv_r = dsp_r(reshape([nd*2-1;nd*2],8,1),tt);
            uuvv = dsp(reshape([nd*2-1;nd*2],8,1),tt);
%             uuvv_r = vel_r(reshape([nd*2-1;nd*2],8,1),tt);
%             uuvv = vel(reshape([nd*2-1;nd*2],8,1),tt);
%             uuvv_r = acc_r(reshape([nd*2-1;nd*2],8,1),tt);
%             uuvv = acc(reshape([nd*2-1;nd*2],8,1),tt);
            %��ù�������
            beta = shape_q4(xcoord,ycoord,uuvv);
            beta_r = shape_q4(xcoord,ycoord,uuvv_r);
            
            shape = [1,ixx,iyy,ixx*iyy,0,0,0,0
                0,0,0,0,1,ixx,iyy,ixx*iyy];
            
            dsp_uv_r(:,ii) = shape*beta_r;
            dsp_uv(:,ii) = shape*beta;
%             vel_uv_r(:,ii) = shape*beta_r;
%             vel_uv(:,ii) = shape*beta;
%             acc_uv_r(:,ii) = shape*beta_r;
%             acc_uv(:,ii) = shape*beta;
            break
        end
    end
    
    
end
figure(5)
hold off
% plot(xx, dsp_uv_r(1,:),'*',xx,dsp_uv(1,:),'+')
plot(yy, dsp_uv_r(1,:),'*',yy,dsp_uv(1,:),'+')
% plot(yy, vel_uv_r(1,:),'*',yy,vel_uv(1,:),'+')
% plot(yy, acc_uv_r(1,:),'*',yy,acc_uv(1,:),'+')
xlabel('yy.  (m)')
ylabel('  disp. (m)')
legend('POD','FEM')
% save(['G:\E��\tables_old\table1226\���\������ݼ�¼\��ͼ0108\ab\','w11x200.mat'],'I200a');
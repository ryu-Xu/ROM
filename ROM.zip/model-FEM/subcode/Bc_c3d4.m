function[B]=Bc_c3d4(nnel,dndx,dndy,dndz)
%������ԪӦ�����B
% B=zeros(6,12);%��ԪӦ�����Ŀվ���
% for i = 1:nnel
%         Be=[dndx(i) 0 0
%         0 dndy(i) 0
%         0 0 dndz(i)
%         dndy(i) dndx(i) 0
%         0 dndz(i) dndy(i)
%         dndz(i) 0 dndx(i)];
%     B(:,3*(i-1)+1:3*i)=B(:,3*(i-1)+1:3*i)+Be;
% end
mat = [
    1     0     0
    0     0     0
    0     0     0
    0     0     0
    0     0     1
    0     1     0
    0     0     0
    0     1     0
    0     0     0
    0     0     1
    0     0     0
    1     0     0
    0     0     0
    0     0     0
    0     0     1
    0     1     0
    1     0     0
    0     0     0];
dNdxyz = [dndx,dndy,dndz]';
temp = mat*dNdxyz;
B = reshape(temp,[6,numel(temp)/6]);
end
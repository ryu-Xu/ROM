
clear;
addpath(genpath('../subcode'));
tic
nodes_data=dlmread('FEMn03.txt',',');
elements=dlmread('FEMe03.txt',',');

gcoord=nodes_data(:,2:3);
nodes=elements(:,2:5);
nnode=size(gcoord,1);
nel=size(nodes,1);
nnel=size(nodes,2);%
ndof=2;%ÿ���ڵ����ɶ���
sdof=nnode*ndof;%ϵͳ�����ɶ���
edof=nnel*ndof;%ÿ����Ԫ���ɶ���

elastic=2.1e11;%����ģ������λPa��N/m2
poisson=0.30;%���ɱ�
damping=0;%����ϵ��
density=7850;%�ܶȣ���λKg/m3

nglx = 2; ngly = 2;%��˹���ֵ���

bcdof=zeros(sdof,1);
fpos = [];%ʩ���غɵ����ɶ����Ҳ�
for i = 1:size(gcoord,1)
    inx = gcoord(i,1);
    iny = gcoord(i,2);
    if inx == -4
        bcdof(2*i-1) = 1;
        bcdof(2*i) = 1;
%         bcval = [bcval;[0,0]];
    elseif inx == 4
        fpos = [fpos,2*i-1];
    end
end



%-----------------------------------------
% ��ʼ����������
%-----------------------------------------

kk=sparse(sdof,sdof);%����նȾ���Ŀվ���
mm=sparse(sdof,sdof);%����������
cc=sparse(sdof,sdof);%���������

[point2,weight2]=feglqd2(nglx,ngly);  % sampling points & weights
D=Dc(1,elastic,poisson);%���Ծ���

t1 = toc;
%-----------------------------------------------------------------
% ����նȾ��������������������װ
%-----------------------------------------------------------------

for iel=1:nel               % loop for the total number of elements

nd = nodes(iel,:);
xcoord = gcoord(nd,1);
ycoord = gcoord(nd,2);

k=zeros(edof,edof);         % initialization of element matrix to zero
m=zeros(edof,edof);
c=zeros(edof,edof);
%--------------------------------
%  ��ֵ����
%--------------------------------

for intx=1:nglx
x=point2(intx,1);                  % sampling point in x-axis
wtx=weight2(intx,1);               % weight in x-axis
for inty=1:ngly
y=point2(inty,2);                  % sampling point in y-axis
wty=weight2(inty,2) ;              % weight in y-axis

[shape,dhdr,dhds]=feisoq4_2(x,y); % compute shape functions and
                                      % derivatives at sampling point

jacob2=fejacob2(nnel,dhdr,dhds,xcoord,ycoord);  % compute Jacobian

detjacob=det(jacob2);                 % determinant of Jacobian
if detjacob<= 0
    disp("buxing")
end
invjacob=inv(jacob2);                 % inverse of Jacobian matrix

[dhdx,dhdy]=federiv2(nnel,dhdr,dhds,invjacob); % derivatives w.r.t.
                                               % physical coordinate
B=Bc2(nnel,dhdx,dhdy);
%------------------------------
%  ���㵥Ԫ����
%------------------------------

k=k+B'*D*B*wtx*wty*detjacob;

m=m+density*(shape'*shape)*wtx*wty*detjacob;

end
end                                   % end of numerical integration loop

index=feeldof(nd,nnel,ndof);% extract system dofs associated with element

%----------------------------------
% ��װ����
%----------------------------------

kk=feasmbl1(kk,k,index);    
mm=feasmbl1(mm,m,index);  % assemble element matrices 
end                        % end of element loops
t2 = toc;
%----------------------------------
% ���
%----------------------------------
dt = 5e-6;
nt=800;
time=0:dt:nt*dt;
q0=zeros(sdof,1);
dq0=zeros(sdof,1);
fd=zeros(sdof,nt);
fd(fpos,:) = 1e7/length(fpos);
tic

[acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0);%newmark
t3 = toc;
%----------------------------------
% POD���
%----------------------------------
tic


L = 20;%˲�����
r = 10;%������
snapshots_d = dsp(:,1:L);%ȡǰ20��ʱ�䲽��Ϊ˲��
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);

[U,~,~]=svd(snapshots_d);
phy = U(:,1:r);
[acc_r,vel_r,dsp_r]=NewmarkPOD(kk,cc,mm,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a);
t4 = toc;

%% plot
for i = 1:sdof
    plot(time,dsp(i,:),'-',...
        time,dsp_r(i,:),'--')
pause(0.01)
end

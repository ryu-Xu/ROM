clear;
clc;
addpath("subcode")
addpath("data")
%% settings
% time step
dt = 5e-6;
nt=800;
time=0:dt:nt*dt;
%load and matrix
load("data1")
% initial boundary conditions
sdof = size(bcdof,1);
q0=zeros(size(bcdof));
dq0=zeros(size(bcdof));

%% FOM
tic
[acc,vel,dsp]=TransResp5(kk,cc,mm,fd,bcdof,nt,dt,q0,dq0);%Newmark
t1 = toc;

%% ROM
L = 20;%number of snapshots
r = 10;%number of basis
snapshots_d = dsp(:,1:L);
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);
[U,~,~]=svd(snapshots_d);
phy = U(:,1:10);% initial bases

tic
[acc_r,vel_r,dsp_r]=NewmarkPOD(kk,cc,mm,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a);
t2 = toc;

%% plot and verification
ratio = (t1/(nt+1))/(t2/(nt+1-L));
for point = 1:sdof
% point = 1; % select dof
plot(time,dsp(point,:),time,dsp_r(point,:))
pause(0.1)
end
function plate_hole = geo_plate_with_hole_4patch(length, radius)
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
% Using two patches to build one-quarter of a square plate with hole
% Input:
%   length - length of the side = 1/2 side length of the initial square
%   radius - radius of the hole
%
%  ---------------------------------------
%  Please feel free to contact us with any questions! 
%  - Xiaoxiao Du, Beihang University
%  - duxxhf@gmail.com / duxiaoxiao@buaa.edu.cn
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%

if nargin ~= 2    % default parameters
    length = 4;  % side length
    radius = 1;  % radius
end
L = length;
R = radius;
alpha = 22.5/180*pi;
w = cos(alpha)^2;

% define control points and knots vector of patch 1
coefs1 = zeros(4,4,3);
coefs1(:,:,1) = [0, R, 0, 1; R*tan(alpha)*w, R*w, 0, w; R*w, R*tan(alpha)*w, 0, w; R, 0, 0, 1]';
coefs1(:,:,2) = [0, (R+L)/2, 0, 1; (R+L)/2*tan(alpha)*w, (R+L)/2*w, 0, w; (R+L)/2*w, (R+L)/2*tan(alpha)*w, 0, w; (R+L)/2, 0, 0, 1]';
coefs1(:,:,3) = [0, L, 0, 1; L*w, L*w, 0, w; L*w, L*w, 0, w; L, 0, 0, 1]';
knots1{1} = [0 0 0 0.5 1 1 1];
knots1{2} = [0 0 0 1 1 1];
% build patch 1 by using control points and knots vector
plate_hole1 = nrbmak(coefs1, knots1);

% define control points and knots vector of patch 2
coefs2 = zeros(4,4,3);
coefs2(:,:,1) = [R, 0, 0, 1; R*w, -R*tan(alpha)*w, 0, w; R*tan(alpha)*w, -R*w, 0, w; 0, -R, 0, 1]';
coefs2(:,:,2) = [(R+L)/2, 0, 0, 1; (R+L)/2*w, -(R+L)/2*tan(alpha)*w, 0, w; (R+L)/2*tan(alpha)*w, -(R+L)/2*w, 0, w; 0, -(R+L)/2, 0, 1]';
coefs2(:,:,3) = [L, 0, 0, 1; L*w, -L*w, 0, w; L*w, -L*w, 0, w; 0, -L, 0, 1]';
knots2{1} = [0 0 0 0.5 1 1 1];
knots2{2} = [0 0 0 1 1 1];
% build patch 2 by using control points and knots vector
plate_hole2 = nrbmak(coefs2, knots2);

% define control points and knots vector of patch 3
coefs3 = zeros(4,4,3);
coefs3(:,:,1) = [0, -R, 0, 1; -R*tan(alpha)*w, -R*w, 0, w; -R*w, -R*tan(alpha)*w, 0, w; -R, 0, 0, 1]';
coefs3(:,:,2) = [0, -(R+L)/2, 0, 1; -(R+L)/2*tan(alpha)*w, -(R+L)/2*w, 0, w; -(R+L)/2*w, -(R+L)/2*tan(alpha)*w, 0, w; -(R+L)/2, 0, 0, 1]';
coefs3(:,:,3) = [0, -L, 0, 1; -L*w, -L*w, 0, w; -L*w, -L*w, 0, w; -L, 0, 0, 1]';
knots3{1} = [0 0 0 0.5 1 1 1];
knots3{2} = [0 0 0 1 1 1];
% build patch 1 by using control points and knots vector
plate_hole3 = nrbmak(coefs3, knots3);

% define control points and knots vector of patch 4
coefs4 = zeros(4,4,3);
coefs4(:,:,1) = [-R, 0, 0, 1; -R*w, R*tan(alpha)*w, 0, w; -R*tan(alpha)*w, R*w, 0, w; 0, R, 0, 1]';
coefs4(:,:,2) = [-(R+L)/2, 0, 0, 1; -(R+L)/2*w, (R+L)/2*tan(alpha)*w, 0, w; -(R+L)/2*tan(alpha)*w, (R+L)/2*w, 0, w; 0, (R+L)/2, 0, 1]';
coefs4(:,:,3) = [-L, 0, 0, 1; -L*w, L*w, 0, w; -L*w, L*w, 0, w; 0, L, 0, 1]';
knots4{1} = [0 0 0 0.5 1 1 1];
knots4{2} = [0 0 0 1 1 1];
% build patch 1 by using control points and knots vector
plate_hole4 = nrbmak(coefs4, knots4);
% % degeree elevate  of patch 1 2 3 4
deop = 2;
plate_hole1 = nrbdegelev(plate_hole1,[deop,deop]);
plate_hole2 = nrbdegelev(plate_hole2,[deop,deop]);
plate_hole3 = nrbdegelev(plate_hole3,[deop,deop]);
plate_hole4 = nrbdegelev(plate_hole4,[deop,deop]);
% % % % % insert knots into patch 1 2 3 4
RefinementX = 2;    % the number of knots inseted in u direction 
RefinementY = 2;    % the number of knots inseted in v direction
iuknots = 1/(RefinementX+1):1/(RefinementX+1):RefinementX/(RefinementX+1);
ivknots = 1/(RefinementY+1):1/(RefinementY+1):RefinementY/(RefinementY+1);
plate_hole1 = nrbkntins(plate_hole1, {iuknots ivknots});
plate_hole2 = nrbkntins(plate_hole2, {iuknots ivknots});
plate_hole3 = nrbkntins(plate_hole3, {iuknots ivknots});
plate_hole4 = nrbkntins(plate_hole4, {iuknots ivknots});

% plot patch 1 2 3 4
figure
hold on;
plot_nurbs(plate_hole1, 0,1);
plot_nurbs(plate_hole2, 0,1);
plot_nurbs(plate_hole3, 0,1);
plot_nurbs(plate_hole4, 0,1);
axis([-inf,inf,-inf,inf]);
view(2);

plate_hole = cell(1,4);
plate_hole{1} = plate_hole1;
plate_hole{2} = plate_hole2;
plate_hole{3} = plate_hole3;
plate_hole{4} = plate_hole4;
end


function bentpipe = geo_bentpipe
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
% Build a bentpipe
%
%  ---------------------------------------
%  Please feel free to contact us with any questions! 
%  - Xiaoxiao Du, Beihang University
%  - duxxhf@gmail.com / duxiaoxiao@buaa.edu.cn
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%

coefs = zeros(4,9,2,5);

s = 1/sqrt(2);
coefs(:,1,1,1) = [1 0 4 1];coefs(:,1,2,1) = [2 0 4 1];
coefs(:,1,1,2) = [1 0 2.5 1];coefs(:,1,2,2) = [2 0 2.5 1];
coefs(:,1,1,3) = [1 0 1 1];coefs(:,1,2,3) = [2 0 1 1];
coefs(:,1,1,4) = [1 0 -1 s];coefs(:,1,2,4) = [2 0 0 s];
coefs(:,1,1,5) = [3 0 -1 1];coefs(:,1,2,5) = [3 0 0 1];

coefs(:,2,1,1) = [1 1 4 s];coefs(:,2,2,1) = [2 2 4 s];
coefs(:,2,1,2) = [1 1 2.5 s];coefs(:,2,2,2) = [2 2 2.5 s];
coefs(:,2,1,3) = [1 1 1 s];coefs(:,2,2,3) = [2 2 1 s];
coefs(:,2,1,4) = [1 1 -1 1/2];coefs(:,2,2,4) = [2 2 0 1/2];
coefs(:,2,1,5) = [3 1 -1 s];coefs(:,2,2,5) = [3 2 0 s];

coefs(:,3,1,1) = [0 1 4 1];coefs(:,3,2,1) = [0 2 4 1];
coefs(:,3,1,2) = [0 1 2.5 1];coefs(:,3,2,2) = [0 2 2.5 1];
coefs(:,3,1,3) = [0 1 1 1];coefs(:,3,2,3) = [0 2 1 1];
coefs(:,3,1,4) = [0 1 -2 s];coefs(:,3,2,4) = [0 2 -2 s];
coefs(:,3,1,5) = [3 1 -2 1];coefs(:,3,2,5) = [3 2 -2 1];

coefs(:,4,1,1) = [-1 1 4 s];coefs(:,4,2,1) = [-2 2 4 s];
coefs(:,4,1,2) = [-1 1 2.5 s];coefs(:,4,2,2) = [-2 2 2.5 s];
coefs(:,4,1,3) = [-1 1 1 s];coefs(:,4,2,3) = [-2 2 1 s];
coefs(:,4,1,4) = [-1 1 -3 1/2];coefs(:,4,2,4) = [-2 2 -4 1/2];
coefs(:,4,1,5) = [3 1 -3 s];coefs(:,4,2,5) = [3 2 -4 s];

coefs(:,5,1,1) = [-1 0 4 1];coefs(:,5,2,1) = [-2 0 4 1];
coefs(:,5,1,2) = [-1 0 2.5 1];coefs(:,5,2,2) = [-2 0 2.5 1];
coefs(:,5,1,3) = [-1 0 1 1];coefs(:,5,2,3) = [-2 0 1 1];
coefs(:,5,1,4) = [-1 0 -3 s];coefs(:,5,2,4) = [-2 0 -4 s];
coefs(:,5,1,5) = [3 0 -3 1];coefs(:,5,2,5) = [3 0 -4 1];

coefs(:,6,1,1) = [-1 -1 4 s];coefs(:,6,2,1) = [-2 -2 4 s];
coefs(:,6,1,2) = [-1 -1 2.5 s];coefs(:,6,2,2) = [-2 -2 2.5 s];
coefs(:,6,1,3) = [-1 -1 1 s];coefs(:,6,2,3) = [-2 -2 1 s];
coefs(:,6,1,4) = [-1 -1 -3 1/2];coefs(:,6,2,4) = [-2 -2 -4 1/2];
coefs(:,6,1,5) = [3 -1 -3 s];coefs(:,6,2,5) = [3 -2 -4 s];

coefs(:,7,1,1) = [0 -1 4 1];coefs(:,7,2,1) = [0 -2 4 1];
coefs(:,7,1,2) = [0 -1 2.5 1];coefs(:,7,2,2) = [0 -2 2.5 1];
coefs(:,7,1,3) = [0 -1 1 1];coefs(:,7,2,3) = [0 -2 1 1];
coefs(:,7,1,4) = [0 -1 -2 s];coefs(:,7,2,4) = [0 -2 -2 s];
coefs(:,7,1,5) = [3 -1 -2 1];coefs(:,7,2,5) = [3 -2 -2 1];

coefs(:,8,1,1) = [1 -1 4 s];coefs(:,8,2,1) = [2 -2 4 s];
coefs(:,8,1,2) = [1 -1 2.5 s];coefs(:,8,2,2) = [2 -2 2.5 s];
coefs(:,8,1,3) = [1 -1 1 s];coefs(:,8,2,3) = [2 -2 1 s];
coefs(:,8,1,4) = [1 -1 -1 1/2];coefs(:,8,2,4) = [2 -2 0 1/2];
coefs(:,8,1,5) = [3 -1 -1 s];coefs(:,8,2,5) = [3 -2 0 s];

coefs(:,9,1,1) = [1 0 4 1];coefs(:,9,2,1) = [2 0 4 1];
coefs(:,9,1,2) = [1 0 2.5 1];coefs(:,9,2,2) = [2 0 2.5 1];
coefs(:,9,1,3) = [1 0 1 1];coefs(:,9,2,3) = [2 0 1 1];
coefs(:,9,1,4) = [1 0 -1 s];coefs(:,9,2,4) = [2 0 0 s];
coefs(:,9,1,5) = [3 0 -1 1];coefs(:,9,2,5) = [3 0 0 1];


for k = 1:5
    for j = 1:2
        for i = 1:9
            coefs(1:3,i,j,k) = coefs(1:3,i,j,k) * coefs(4,i,j,k);
        end
    end
end

knots{1} = [0,0,0,1/4,1/4,2/4,2/4,3/4,3/4,1,1,1];
knots{2} = [0 0 1 1];
knots{3} = [0, 0, 0, 1/2, 1/2, 1, 1, 1];

% build nurbs solid by using control points and knots vector
bentpipe = nrbmak(coefs, knots);
% 
% degeree elevate
% deop = 5;
% bentpipe = nrbdegelev(bentpipe,[deop,deop,deop]);
% % insert knots
% ikop = 18;
% RefinementX = ikop;    % the number of knots inseted in u direction 
% RefinementY = ikop;    % the number of knots inseted in v direction
% RefinementZ = ikop;    % the number of knots inseted in w direction
% iuknots = 1/(RefinementX+1):1/(RefinementX+1):RefinementX/(RefinementX+1);
% ivknots = 1/(RefinementY+1):1/(RefinementY+1):RefinementY/(RefinementY+1);
% iwknots = 1/(RefinementZ+1):1/(RefinementZ+1):RefinementZ/(RefinementZ+1);
% bentpipe = nrbkntins(bentpipe, {iuknots ivknots iwknots});

% plot nurbs solid
% plot_nurbs(bentpipe, 0,1);
% axis equal
end



function[kk]=bck2(bcdof,kk)
% ʩ�ӱ߽�����
nbc  = length(bcdof);
for i=1:nbc
    if bcdof(i) == 1
        kk(i,:)=0;
        kk(:,i)=0;
        kk(i,i)=1;
    end
end
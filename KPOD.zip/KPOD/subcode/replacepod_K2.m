function [phy_n,kker] = replacepod_K2(kke,u,e,kry)
for i = 1:kry
    K(:,i) = integerMpower(kke,(i-1))*e;
end

[U,~,~] = svd(u);
U = U(:,1:10);
phy_n = [U,K];
% phy_n = Schmidt_orthogonalization(phy_n);

for i = 1:size(phy_n,2)
    phy_n(:,i) = phy_n(:,i)/norm(phy_n(:,i));
end
kker = phy_n'*kke*phy_n;
end
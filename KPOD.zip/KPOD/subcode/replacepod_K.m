function [phy_n,kker] = replacepod_K(phy,kke,ur,e,kry)
for i = 1:kry
    K(:,i) = integerMpower(kke,(i-1))*e;
end
for i = 1:size(ur,1)
    urv(:,i) = ur{i};
end
[U,~,~] = svd(urv);
phy_n = [phy*U,K];
% phy_n = Schmidt_orthogonalization(phy_n);

for i = 1:size(phy_n,2)
    phy_n(:,i) = phy_n(:,i)/norm(phy_n(:,i));
end
kker = phy_n'*kke*phy_n;
end
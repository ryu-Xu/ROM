function [acc,vel,dsp]=NewmarkPOD(kk,cc,mm,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a)
%--------------------------------------------------------------------------
%  Purpose:
%     The function subroutine NewmarkPOD.m calculates transient response of
%     a structural system using Newmark integration scheme with ROM.
%  Synopsis:
%     [acc,vel,dsp]=NewmarkPODkk,cc,mm,fd,bcdof,nt,dt,phy,...
%    snapshots_d,snapshots_v,snapshots_a)
%  Variable Description:
%     Input parameters
%       kk, cc, mm - stiffness, damping and mass matrices
%       fd - Input or forcing influence matrix
%       bcdof - Boundary condition dofs vector
%       nt - Number of time steps
%       dt - Time step size
%       phy - initial bases
%       snapshots_d - snapshots of displacement
%       snapshots_v - snapshots of velocity
%       snapshots_a - snapshots of acceleration
%     Output parameters
%       acc - Acceleration response
%       vel - Velocity response
%       dsp - Displacement response
%--------------------------------------------------------------------------
%  (1) initial condition
%--------------------------------------------------------------------------
sdof = size(phy,1);
L = size(snapshots_d,2);
dsp=zeros(sdof,nt);% displacement matrix
vel=zeros(sdof,nt);% velocity matrix
acc=zeros(sdof,nt);% acceleration matrix
dsp(:,1:L) = snapshots_d;
vel(:,1:L) = snapshots_v;
acc(:,1:L) = snapshots_a;
dsp_r = cell(1+nt,1);% reduced order solutions
for i = 1:L
dsp_r{i} = phy'*dsp(:,i);
end
alpha=0.8; beta=1;
threshold = 1e-10;% error threshold
%--------------------------------------------------------------------------
%  (2) NewmarkPOD integration scheme for time integration
%--------------------------------------------------------------------------
ekk=kk+mm/(alpha*dt^2)+cc*beta/(alpha*dt); % effective stiffness matrix
ekk = bck2(bcdof,ekk);
ekk_r = phy'*ekk*phy;
jishu = 0;
for it=L:nt % loop for each time step
jishu = jishu + 1;
% Updating basis method
    if mod(it,401) == 0
        snapshots = dsp(:,it-9:it);
        U = s_svd(snapshots);
        phy = U(:,1:10);
        ekk_r = phy'*ekk*phy;
        for i = 1:3
            dsp_r{it-3+i} = phy'*dsp(:,it-3+i);
        end
    end
  cfm=dsp(:,it)/(alpha*dt^2)+vel(:,it)/(alpha*dt)+acc(:,it)*(0.5/alpha-1);
  cfc=dsp(:,it)*beta/(alpha*dt)+vel(:,it)*(beta/alpha-1)...
     +acc(:,it)*(0.5*beta/alpha-1)*dt;
  efd=fd(:,it)+mm*cfm+cc*cfc;%  compute the effective force vector
  efd = bcf2(bcdof,efd);
  efd_r = phy'*efd;
  dsp_r{it+1} = ekk_r\efd_r;
  dsp(:,it+1) = phy*dsp_r{it+1};
  acc(:,it+1)=(dsp(:,it+1)-dsp(:,it))/(alpha*dt^2)-vel(:,it)/(alpha*dt)...
              -acc(:,it)*(0.5/alpha-1);
  vel(:,it+1)=vel(:,it)+acc(:,it)*(1-beta)*dt+acc(:,it+1)*beta*dt;
  
    if jishu == 3
        jishu = 0;
    e = ekk*dsp(:,it+1)-efd;
    el2 = sqrt(norm(e,2)/norm(efd,2));
    if el2>threshold
         [phy,ekk_r] = replacepod_K(phy,ekk,dsp_r(it-1:it+1),e,2);% update POD basis
%          [phy,ekk_r] = replacepod_K2(ekk,dsp(:,it-9:it+1),e,2);% update POD basis with high dimension SVD
    end
    end               
end
disp('The method is Newmark POD integration')
end

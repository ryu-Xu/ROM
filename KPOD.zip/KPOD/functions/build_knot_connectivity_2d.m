function [ elNodeCnt, elDoma ] = build_knot_connectivity_2d( uknot, vknot )
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
%  Build node element contivity from two dimensional knot vector
%  Input:
%    uknots - uknot vector
%    vknots - vknot vector
%  Output:
%    elNodeCnt - node connectivity
%    elDoma - element parameter domain
%  ---------------------------------------
%  Please feel free to contact us with any questions! 
%  - Xiaofei Liu  Hunan University
%  - ryuxiaofei@hnu.edu.cn
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
p = length(find(uknot == uknot(1)))-1;  % udegree
q = length(find(vknot == vknot(1)))-1;  % vdegree
nCptsU = length(uknot) - p - 1;         % number of control points in u-direction
nCptsV = length(vknot) - q - 1;         % number of control points in v-direction
[elNodeCntU, elDomaU] = build_knot_connectivity( uknot );
[elNodeCntV, elDomaV] = build_knot_connectivity( vknot );
nElemU = size(elNodeCntU,1);               % number of elemens in u direction
nElemV = size(elNodeCntV,1);               % number of elemens in v direction
nElems = nElemU * nElemV;      % total number of elements
nElemCpts = (p+1) * (q+1);   % total number of nodes in one element
elNodeCnt = zeros( nElems, nElemCpts );  % element node connectivity
elDoma = zeros(nElems, 4);      % elements' parametric domain [u1 u2 v1 v2; u1 u2 v1 v2;...]
count = 0;

for j = 1:nElemV
    for i = 1:nElemU
        count = count + 1;
        for hh = 1:q+1
            for gg = 1:p+1
                qq = (hh-1)*(p+1) + gg;
                % build element-node connectivity
                elNodeCnt(count,qq) = (elNodeCntV(j,hh)-1)*nCptsU + elNodeCntU(i,gg);   
            end
        end
        elDoma(count,:) = [elDomaU(i,:) elDomaV(j,:)];   % record elements' parametric domain
    end
end    
end


%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
%  plate with hole;
%  The model is built with 4 NURBS patches.
%  Here for multipatch problem, we only condider the multiple NURBS patches
%  with same degrees, knot vector and control points on the interfaces.
%
%  ---------------------------------------
%  Please feel free to contact us with any questions! 
%  - Xiaofei Liu, Hunan University
%  - ryuxiaofei@hnu.edu.cn
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%

clc; 
clear all;

E            = 2.1e11;  % Youngs modulus
nu           = 0.3;  % Poisson ratio
a            = 1;    % radius of the hole
density      = 7850; % density
damping      = 0;
L            = 4;    % length of the plate
D0 = E/(1-nu^2)*[  1      nu        0;
                  nu     1          0;
                  0      0      (1-nu)/2  ];
dof = 2;             % degree of freedom
% define the geometry
plate_hole = geo_plate_with_hole_4patch(L,a);

% build iga mesh structure
mesh = cell(1,length(plate_hole));
for i = 1:length(plate_hole)
    mesh{1,i} = build_iga_mesh( plate_hole{1,i} );   
    mesh{1,i}.gloElNodeCnt = mesh{1,i}.elNodeCnt;
    mesh{1,i}.nodeNum = zeros(mesh{1,i}.nCptsV, mesh{1,i}.nCptsU);
end

% node numbering
for j = 1:mesh{1,1}.nCptsV
    for i = 1:mesh{1,1}.nCptsU
        mesh{1,1}.nodeNum(j,i) = (j-1)*(mesh{1,1}.nCptsU)+i;
    end
end

mesh{1,2}.nodeNum(:,1) = mesh{1,1}.nodeNum(:,end);
for j = 1:mesh{1,2}.nCptsV
    for i = 2:mesh{1,2}.nCptsU
        mesh{1,2}.nodeNum(j,i) = (j-1)*(mesh{1,2}.nCptsU-1)+i-1 + mesh{1,1}.nCpts;
    end
end

mesh{1,3}.nodeNum(:,1) = mesh{1,2}.nodeNum(:,end);
for j = 1:mesh{1,3}.nCptsV
    for i = 2:mesh{1,3}.nCptsU
        mesh{1,3}.nodeNum(j,i) = (j-1)*(mesh{1,3}.nCptsU-1)+i-1 + mesh{1,2}.nodeNum(end,end);
    end
end

mesh{1,4}.nodeNum(:,1) = mesh{1,3}.nodeNum(:,end);
for j = 1:mesh{1,4}.nCptsV
    for i = 2:mesh{1,4}.nCptsU-1
        mesh{1,4}.nodeNum(j,i) = (j-1)*(mesh{1,4}.nCptsU-2)+i-1 + mesh{1,3}.nodeNum(end,end);
    end
end
mesh{1,4}.nodeNum(:,end) = mesh{1,1}.nodeNum(:,1);
% reconstruct global nodes coordinates
globNodeNum = mesh{1,1}.nCpts + mesh{1,2}.nCpts + mesh{1,3}.nCpts + mesh{1,4}.nCpts -...
    mesh{1,1}.nCptsV - mesh{1,2}.nCptsV - mesh{1,3}.nCptsV - mesh{1,4}.nCptsV;
globCoords = zeros(globNodeNum,4);
globCoords(1:mesh{1,1}.nCpts,:) = mesh{1,1}.coords;
count = mesh{1,1}.nCpts;
for j = 1:mesh{1,2}.nCptsV
    for i = 2:mesh{1,2}.nCptsU
        count = count+1;
        k = (j-1)*(mesh{1,2}.nCptsU) +i;
        globCoords(count,:) = mesh{1,2}.coords(k,:);
    end
end
count = mesh{1,2}.nodeNum(end,end);
for j = 1:mesh{1,3}.nCptsV
    for i = 2:mesh{1,3}.nCptsU
        count = count+1;
        k = (j-1)*(mesh{1,3}.nCptsU) +i;
        globCoords(count,:) = mesh{1,3}.coords(k,:);
    end
end
count = mesh{1,3}.nodeNum(end,end);
for j = 1:mesh{1,4}.nCptsV
    for i = 2:mesh{1,4}.nCptsU-1
        count = count+1;
        k = (j-1)*(mesh{1,4}.nCptsU) +i;
        globCoords(count,:) = mesh{1,4}.coords(k,:);
    end
end


% build global node element connectivity
relation_pos = cell(mesh{1,1}.nCpts,1);
for i = 1:mesh{1,1}.nCpts
    relation_pos{i,1} = find(mesh{1,1}.gloElNodeCnt == mesh{1,1}.nodeNum(i));
end
for ipatch = 2:4
    for i = 1:mesh{1,ipatch}.nCpts
        mesh{1,ipatch}.gloElNodeCnt(relation_pos{i,1}) = mesh{1,ipatch}.nodeNum(i);
    end
end

% find the boundary nodes
leftNodes = [];
rightNodes = [];
trans11 = mesh{1,1}.nodeNum';
trans12 = mesh{1,2}.nodeNum';
trans13 = mesh{1,3}.nodeNum';
trans14 = mesh{1,4}.nodeNum';
leftNodes   = [leftNodes,trans14(find(mesh{1,4}.coords(:,1)==-4));...
    trans13(find(mesh{1,3}.coords(:,1)==-4))];
leftNodes = sort(unique(leftNodes));
dbc = [];    % dbc = [node index, direction, prescribed displacement]
dbc = [dbc; leftNodes,     ones(size(leftNodes)),   zeros(size(leftNodes));
    leftNodes,     2*ones(size(leftNodes)),   zeros(size(leftNodes))];

scatdbc = [];
scattbc = [];
if ~isempty(dbc)
    scatdbc = dof * (dbc(:,1)-1) + dbc(:,2);   % scatter dbc
end

% initialize stiffness and force matrices
nDofs = dof * globNodeNum;    % total dofs
K = sparse(nDofs,nDofs);     % stiffness matrix 
C = sparse(nDofs,nDofs);
M = sparse(nDofs,nDofs);     % mass matrix
F = zeros(nDofs,1);          % external force matrix

% use gaussian integration rule
gp_x = mesh{1,1}.p+1;           % number of integration points in x-direction
gp_y = mesh{1,1}.q+1;           % number of integration points in y-direction
[gp, wgt] = gauss_quadrature(gp_x, gp_y);   % calculate integration points and its weights
for jj = 1:length(mesh)
    for e = 1:mesh{1,jj}.nElems                 % loop over elements
        sctr   = mesh{1,jj}.gloElNodeCnt(e,:);  % element control points index
        elDoma = mesh{1,jj}.elDoma(e,:);        % element parametric domain
        elCpts = globCoords(sctr,:);     % coordinates of element control points
        nn     = numel(sctr);             % number of control points for each element
        nnElem = nn*dof;                  % dof for each element
        sctrB  = zeros(1, nnElem); 
        for i = 1:dof
            sctrB(i:dof:nnElem) = dof*(sctr-1) + i;  % displacement in i-th direction
        end  
        for ipt = 1:size(gp,1)        % loop over integration points
            pt      = gp(ipt,:);      % reference parametric coordinates for each integration point
            wt      = wgt(ipt);       % weigths for each integration point
            gauPts  = parameter_gauss_mapping( elDoma, pt );       % gauss integration mapping
            j1      = jacobian_gauss_mapping( elDoma );            % jacobian value for gauss mapping   
            [R,ders] = nurbs_derivatives( gauPts, plate_hole{1,jj}, mesh{1,jj} );
            jmatrix = ders*elCpts(:,1:2); 
            j2      = det(jmatrix);
            dR_dx   =  jmatrix \ ders;     
            B = zeros(3,nnElem); 
            B(1,1:2:nnElem) = dR_dx(1,:);  
            B(2,2:2:nnElem) = dR_dx(2,:);   
            B(3,1:2:nnElem) = dR_dx(2,:);   
            B(3,2:2:nnElem) = dR_dx(1,:);   
            fac = j1 *j2 * wt;      
            K(sctrB,sctrB) = K(sctrB,sctrB) + B' * D0 * B * fac;
            Re = zeros(2,nnElem);
            Re(1,1:2:nnElem) = R;
            Re(2,2:2:nnElem) = R;
            M(sctrB,sctrB) = M(sctrB,sctrB) + density * (Re'*Re) * fac;
        end 
    end
end

% boundary conditions imposition on right boundary 1
[forceElems1, forceKnots1] = build_knot_connectivity( mesh{1,1}.uKnots );
forceElems1 = forceElems1 + (mesh{1,1}.nCptsV-1)*mesh{1,1}.nCptsU;
forceNodes1  = trans11(:,end);
gp_x = mesh{1,1}.p+1;
[gp, wgt] = gauss_quadrature(gp_x);
for e = 1:size(forceElems1,1)
    sctr   = forceElems1(e,:);  
    elDoma = forceKnots1(e,:);
    elCpts = globCoords(sctr,:);
    nn     = numel(sctr);
    nnElem = nn*dof;                 
    sctrB  = zeros(1, nnElem); 
    for i = 1:dof
        sctrB(i:dof:nnElem) = dof*(sctr-1) + i;  % displacement in i-th direction
    end   
    for ipt = 1:size(gp,1) 
        pt     = gp(ipt);                                     % quadrature point
        wt     = wgt(ipt);                                    % quadrature weight
        gauPts = parameter_gauss_mapping( elDoma, pt );       % gauss integration mapping
        j1     = jacobian_gauss_mapping( elDoma );            % jacobian value for gauss mapping      
        [N, dNdxi] = nrbNurbs1DBasisDerivs(gauPts, mesh{1,1}.p, mesh{1,1}.uKnots, globCoords(forceNodes1,4));
        j2     = dNdxi*elCpts(:,1:2);            
        j2     = norm(j2);
        if e > mesh{1,1}.nElemU/2  %right edge
            tx  = 1e7/8;
            ty  = 0; 
        else
            tx = 0;
            ty = 0;
        end
        R = zeros(2,nnElem);
        R(1,1:2:nnElem) = N;
        R(2,2:2:nnElem) = N;
        fac = j1 * j2 * wt;
        F(sctrB) = F(sctrB) + R'* [tx; ty] * fac;
    end   
end

% boundary conditions imposition on right boundary 2
[forceElems2, forceKnots2] = build_knot_connectivity( mesh{1,2}.uKnots );
forceNodes2  = trans12(:,end);
for i = 1:size(forceElems2,1)
    forceElems2(i,:) = forceNodes2(forceElems2(i,:));
end
for e = 1:size(forceElems2,1)
    sctr   = forceElems2(e,:);  
    elDoma = forceKnots2(e,:);
    elCpts = globCoords(sctr,:);
    nn     = numel(sctr);
    nnElem = nn*dof;                 
    sctrB  = zeros(1, nnElem); 
    for i = 1:dof
        sctrB(i:dof:nnElem) = dof*(sctr-1) + i;  % displacement in i-th direction
    end   
    for ipt = 1:size(gp,1) 
        pt     = gp(ipt);                                     % quadrature point
        wt     = wgt(ipt);                                    % quadrature weight
        gauPts = parameter_gauss_mapping( elDoma, pt );       % gauss integration mapping
        j1     = jacobian_gauss_mapping( elDoma );            % jacobian value for gauss mapping      
        [N, dNdxi] = nrbNurbs1DBasisDerivs(gauPts, mesh{1,2}.p, mesh{1,2}.uKnots, globCoords(forceNodes2,4));
        j2     = dNdxi*elCpts(:,1:2);            
        j2     = norm(j2); 
        if e <= mesh{1,2}.nElemU/2 %right edge
            tx  = 1e7/8;
            ty  = 0;
        else
            tx = 0;
            ty = 0;
        end
        R = zeros(2,nnElem);
        R(1,1:2:nnElem) = N;
        R(2,2:2:nnElem) = N;
        fac = j1 * j2 * wt;
        F(sctrB) = F(sctrB) + R'* [tx; ty] * fac;
    end   
end

%% solving equations
dt = 5e-6;
nt = 2000;
time = 0:dt:nt*dt;

u0=zeros(nDofs,1);
du0=zeros(nDofs,1);
bcdof=zeros(nDofs,1);
bcdof(scatdbc) = 1;
fd = zeros(nDofs,nt);
% for i = 1 :nt
%     fd(:,i) = F*cos(i*pi/500);
% end
fd = F*ones(1,nt);
% FOM
tic
[acc,vel,dsp]=TransResp5(K,C,M,fd,bcdof,nt,dt,u0,du0);%Newmark
t1 = toc;
% ROM
L = 20;%number of snapshots
r = 10;%number of basis
snapshots_d = dsp(:,1:L);
snapshots_v = vel(:,1:L);
snapshots_a = acc(:,1:L);
[U,~,~]=svd(snapshots_d);
phy = U(:,1:r);% initial bases
tic
[~,~,dsp_r]=NewmarkPOD(K,C,M,fd,bcdof,nt,dt,phy,...
    snapshots_d,snapshots_v,snapshots_a);
t2 = toc;

ratio = (t1/nt)/(t2/(nt-L))

%% post-processing
moment = 2000;
u = dsp(:,moment);
% line_ab
u_knots1 = 0.5:0.05:1;% line ab at mesh{1}
v_knots1 = ones(size(u_knots1));
u_knots2 = 0.05:0.05:0.5;% line ab at mesh{2}
v_knots2 = ones(size(u_knots2));
pt1 = [u_knots1;v_knots1]';
pt2 = [u_knots2;v_knots2]';
xd1 = zeros(size(u_knots1,2),1);
xd2 = zeros(size(u_knots2,2),1);
for in = 1 : size(u_knots1,2)
[R,~] = nurbs_derivatives( pt1(in,:), plate_hole{1,1}, mesh{1,1} );
enum = find_point_span( mesh{1,1},pt1(in,:) );
sctr = mesh{1,1}.gloElNodeCnt(enum,:); % element control points index
xd1(in) = R * dsp(sctr*2-1,moment);
end
for in = 1 : size(u_knots2,2)
[R,~] = nurbs_derivatives( pt2(in,:), plate_hole{1,2}, mesh{1,2} );
enum = find_point_span( mesh{1,2},pt2(in,:) );
sctr = mesh{1,2}.gloElNodeCnt(enum,:); % element control points index
xd2(in) = R * dsp(sctr*2-1,moment);
end

% point a
pt = [1, 1e-15]; %parametric coord 
[R,~] = nurbs_derivatives( pt, plate_hole{1,1}, mesh{1,1} );
enum = find_point_span( mesh{1,1},pt );
sctr = mesh{1,1}.gloElNodeCnt(enum,:); % element control points index
exyz = globCoords(sctr,:); % element control points' coordinates
xd_a = R * dsp_r(sctr*2-1,:);

% cloud map
vmesh = cell(1,length(mesh));
polygon = cell(1,length(mesh));
kntcrv = cell(1,length(mesh)); 
for kk = 1:length(mesh)
    num1 = 50;  % if you want to obtain a more smooth results, please provide large numbers for num1 and num2    
    num2 = 50;
    polygon{1,kk} = build_visual_mesh_suf( num1, num2 );        % build visualized mesh
    kntcrv{1,kk} = build_visual_knotcurve_suf( mesh{1,kk}.uKnots, mesh{1,kk}.vKnots, num1+1 ); % build visualized knot curves
    numpts = (num1+1)*(num2+1) + size(kntcrv{1,kk}.linpts,1);
    vmesh{1,kk}.vertices = zeros(numpts,2);
    vmesh{1,kk}.displacement = zeros(numpts,2);
    vmesh{1,kk}.exactdisplacement = zeros(numpts,2);
    vmesh{1,kk}.stress = zeros(numpts,3);
    vmesh{1,kk}.exactstress = zeros(numpts,3);
    elem_index = find_point_span( mesh{1,kk}, polygon{1,kk}.tripts );
    for i=1:(num1+1)*(num2+1)
        xi = polygon{1,kk}.tripts(i,1);   % u mesh point
        eta = polygon{1,kk}.tripts(i,2);  % v mesh point
        e = elem_index(i);          % element number
        sctr = mesh{1,kk}.gloElNodeCnt(e,:); % element control points index
        exyz = globCoords(sctr,:); % element control points' coordinates
        nn = numel(sctr);           % number of control points for each element
        nnElem = nn*dof;            % dof for each element
        sctrB = zeros(1, nnElem); 
        for k = 1:dof
            sctrB(k:dof:nnElem) = dof*(sctr-1) + k;  % displacement in i-th direction
        end
        [R,dRdparm] = nurbs_derivatives( [xi, eta], plate_hole{1,kk}, mesh{1,kk} );
        jmatrix = dRdparm*exyz(:,1:2); 
        dR_dx =  jmatrix \ dRdparm;   
        B(1,1:2:nnElem) = dR_dx(1,:);  
        B(2,2:2:nnElem) = dR_dx(2,:);   
        B(3,1:2:nnElem) = dR_dx(2,:);   
        B(3,2:2:nnElem) = dR_dx(1,:); 
        strain = B * u(sctrB);
        stress = D0 * strain;
        edsp   = u(sctrB);
        edsp   = reshape(edsp, dof, nn);
        vmesh{1,kk}.displacement(i,:) = R * edsp';
        vmesh{1,kk}.vertices(i,1:2) = R*exyz(:,1:2);
        vmesh{1,kk}.stress(i,:) = stress';
    end
    count = (num1+1)*(num2+1);
    line_index = find_point_span( mesh{1,kk}, kntcrv{1,kk}.linpts );
    kntcrv{1,kk}.linmesh = kntcrv{1,kk}.linmesh + (num1+1)*(num2+1);
    for i = 1:size(kntcrv{1,kk}.linpts,1)
        count = count+1;
        xi = kntcrv{1,kk}.linpts(i,1);
        eta = kntcrv{1,kk}.linpts(i,2);
        e = line_index(i);   % element number
        sctr = mesh{1,kk}.gloElNodeCnt(e,:);     % element control points index
        exyz = globCoords(sctr,:);  % element control points' coordinates
        nn = numel(sctr);           % number of control points for each element
        nnElem = nn*dof;            % dof for each element
        sctrB = zeros(1, nnElem); 
        for k = 1:dof
            sctrB(k:dof:nnElem) = dof*(sctr-1) + k;  % displacement in i-th direction
        end
        [R,dRdparm] = nurbs_derivatives( [xi, eta], plate_hole{1,kk}, mesh{1,kk} );
        jmatrix = dRdparm*exyz(:,1:2); 
        dR_dx =  jmatrix \ dRdparm;   
        B(1,1:2:nnElem) = dR_dx(1,:);  
        B(2,2:2:nnElem) = dR_dx(2,:);   
        B(3,1:2:nnElem) = dR_dx(2,:);   
        B(3,2:2:nnElem) = dR_dx(1,:);  
        strain = B * u(sctrB);
        stress = D0 * strain;
        edsp   = u(sctrB);
        edsp   = reshape(edsp, dof, nn);
        vmesh{1,kk}.displacement(count,:) = R * edsp';
        vmesh{1,kk}.vertices(count,1:2) = R*exyz(:,1:2); 
        vmesh{1,kk}.stress(count,:) = stress';    
    end
end

% plot the solutions
figure;
title( 'Approximate Solutions', 'FontSize', 14', 'FontWeight', 'Bold') ;
axis off;
colX = linspace( 0.1, 0.65, 3 );
rowY = [0.55, 0.15];
for K = 1:3
    rowId = ceil(K/3);
    colId = K - (rowId-1)*3;
    axes( 'Position', [colX(colId), rowY(rowId), 0.3, 0.3] ) ;
    for jj = 1:length(mesh)
        face = polygon{1,jj}.trimesh;
        maxnum = max(max(face));
        vertices = vmesh{1,jj}.vertices(1:maxnum,:);
        displacement = vmesh{1,jj}.displacement(1:maxnum,:);
        stress = vmesh{1,jj}.stress(1:maxnum,:);
        linmesh = kntcrv{1,jj}.linmesh;
        p = patch('Faces',face, 'Vertices', vertices);
        if K == 1,  cdata = displacement(1:maxnum,1); title('U_x');
        elseif K == 2,  cdata = displacement(1:maxnum,2);  title('U_y');
        elseif K == 3,  cdata = sqrt( displacement(1:maxnum,1).^2 + displacement(1:maxnum,2).^2  ); title('U Magnitude');
        end
        hold on;
        set(p,'FaceColor','interp','FaceVertexCData',cdata);
        set(p,'EdgeColor','none');
        for j = 1:size(linmesh,1)
            hold on;
            vv = vmesh{1,jj}.vertices(linmesh(j,:),:);
            plot(vv(:,1), vv(:,2), 'k-');
        end 
        axis equal;
        axis off;
    end
    hold off;
    colorbar;
end

